/**
 * ------------------------------------------------------------------
 * AgentPanel
 * ------------------------------------------------------------------
 * Panel chính của Agent, quản lý chuyển đổi giữa Home và Chat view.
 * Sử dụng keep-alive để bảo toàn state khi chuyển giữa các target/project.
 *
 * Main features:
 * - Keep-alive: mỗi target/project có một AgentView riêng, giữ mounted
 * - handleHomeSendMessage()  : Nhận message từ Home, tạo ChatSession mới
 * - handleBack()             : Quay về Home từ Chat, giữ nội dung dang dở
 * - handleLoadConversation() : Load conversation từ history vào Chat view
 * ------------------------------------------------------------------
 */

import { useState, useCallback, useRef, useEffect, useMemo } from 'react';

// ── Components ──
import HomePanel from './screens/Home';
import ChatPanel from './screens/Chat';
import AgentOverlay from './components/AgentOverlay';
import AccountPanel from './screens/Account';
import HistoryPanel from './screens/History';
import MarketplacePanel from './screens/Marketplace';
import SettingsPanel from './screens/Setting';

// CONTEXT
import { ProjectProvider } from './context/ProjectContext';
import { useAgentFeature, type AgentFeature } from './context/FeatureContext';
import { useDesignStore } from '@renderer/modules/Code/features/design/stores/design.store';
import { useCodeStore } from '@renderer/modules/Code/shared/stores/code.store';

// ── Types ──
import { ChatSession } from './screens/Chat/types/chat';

// ── Utils ── (icons)
import { MousePointer } from 'lucide-react';
import { AgentRootContext } from './context/AgentRootContext';
import { useWorkflowAgentSync } from './context/WorkflowAgentContext';
import { useToolFormatSettings } from './hooks/useToolFormatSettings';

// ─── Page switcher ─────────────────────────────────────────────────────────

type SubView = 'history' | 'marketplace' | 'account' | 'setting' | null;

// ─── AgentView (keep-alive unit) ───────────────────────────────────────────

interface AgentViewProps {
  feature: string;
  isVisible: boolean;
  initialConversationId?: string | null;
  onConversationChange?: (conversationId: string | null) => void;
  onTitleChange?: (title: string | null) => void;
}

/** Một instance Agent cho một target/project cụ thể — luôn mounted, ẩn/hiện bằng CSS */
function AgentView({
  feature,
  isVisible,
  initialConversationId,
  onConversationChange,
  onTitleChange,
}: AgentViewProps) {
  const [currentChat, setCurrentChat] = useState<ChatSession | null>(() =>
    initialConversationId
      ? {
          sessionId: Date.now(),
          folderPath: (window as any).__zenWorkspaceFolderPath || null,
          conversationId: initialConversationId,
          canAccept: true,
        }
      : null,
  );
  const [initialMessageData, setInitialMessageData] = useState<{
    content: string;
    files: any[];
    model: any;
    account: any;
    conversationOverrides?: {
      useSkillEnabled?: boolean;
      memoryEnabled?: boolean;
      toolFormat?: 'xml' | 'json';
    };
  } | null>(null);
  const [homeInitialValue, setHomeInitialValue] = useState('');
  const [subView, setSubView] = useState<SubView>(null);

  const onConversationChangeRef = useRef(onConversationChange);
  onConversationChangeRef.current = onConversationChange;
  const isVisibleRef = useRef(isVisible);
  isVisibleRef.current = isVisible;
  const chatConversationId = currentChat?.conversationId || null;

  const onTitleChangeRef = useRef(onTitleChange);
  onTitleChangeRef.current = onTitleChange;

  // Về Home (không có chat) → xóa title đang hiển thị ở header RightPanel
  useEffect(() => {
    if (isVisible && !currentChat) onTitleChangeRef.current?.(null);
  }, [currentChat, isVisible]);

  const handleChatTitleChange = useCallback((title: string) => {
    if (isVisibleRef.current) onTitleChangeRef.current?.(title);
  }, []);

  useEffect(() => {
    if (!isVisible) return;
    onConversationChangeRef.current?.(chatConversationId);
  }, [chatConversationId, isVisible]);

  const handleChatConversationChange = useCallback((conversationId: string) => {
    if (isVisibleRef.current) onConversationChangeRef.current?.(conversationId);
  }, []);

  // Reset to Home on window reload/refresh
  useEffect(() => {
    const handleBeforeUnload = () => {
      setCurrentChat(null);
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, []);

  const handleHomeSendMessage = useCallback(
    (
      content: string,
      files: any[],
      model: any,
      account: any,
      conversationOverrides?: {
        useSkillEnabled?: boolean;
        memoryEnabled?: boolean;
        toolFormat?: 'xml' | 'json';
        workflowAgentId?: 'orchestrator' | 'planner' | 'executor' | 'reviewer' | null;
      },
    ) => {
      setInitialMessageData({ content, files, model, account, conversationOverrides });
      const newSession: ChatSession = {
        sessionId: Date.now(),
        folderPath: (window as any).__zenWorkspaceFolderPath || null,
        conversationId: '',
        canAccept: true,
      };
      setCurrentChat(newSession);
      setHomeInitialValue('');
    },
    [],
  );

  const workflowSync = useWorkflowAgentSync();
  const handleHomeUserSend = useCallback(
    (...args: Parameters<typeof handleHomeSendMessage>) => {
      if (workflowSync?.agentId === 'orchestrator' && args[0].trim()) {
        workflowSync.notifyUserMessage?.(args[0]);
      }
      handleHomeSendMessage(...args);
    },
    [workflowSync, handleHomeSendMessage],
  );
  const pendingInbox = workflowSync?.inbox?.[0];
  const { toolFormat: inboxToolFormat } = useToolFormatSettings(
    workflowSync?.model?.providerId,
    workflowSync?.model?.id,
  );

  // Deliver send_message to a Zen tab that is still on Home: start its first conversation
  useEffect(() => {
    if (!workflowSync || !pendingInbox) return;
    if (currentChat) {
      return;
    }
    if (!workflowSync.model || !workflowSync.account) {
      return;
    }
    handleHomeSendMessage(
      `<agent-message from="${pendingInbox.from}">\n${pendingInbox.content}\n</agent-message>`,
      [],
      workflowSync.model,
      workflowSync.account,
      {
        toolFormat: inboxToolFormat,
        workflowAgentId: (workflowSync.agentType ?? workflowSync.agentId) as any,
      },
    );
    workflowSync.shiftInbox?.();
  }, [workflowSync, pendingInbox, currentChat, handleHomeSendMessage, inboxToolFormat]);

  const handleBack = useCallback((contentToReturn?: string) => {
    setCurrentChat(null);
    setHomeInitialValue(
      typeof contentToReturn === 'string' && contentToReturn.trim() ? contentToReturn : '',
    );
  }, []);

  const handleLoadConversation = useCallback(
    (conversationId: string, _sessionId: number, folderPath: string | null) => {
      // Clear any pending initial message data so each history load starts fresh
      setInitialMessageData(null);
      // Always generate a new sessionId to ensure useEffect in useConversationRestore triggers
      const newSession: ChatSession = {
        sessionId: Date.now(),
        folderPath: folderPath || (window as any).__zenWorkspaceFolderPath || null,
        conversationId,
        canAccept: true,
      };
      setCurrentChat(newSession);
      setSubView(null);
    },
    [],
  );

  // Listen for reset to home event from RightPanel Plus button
  useEffect(() => {
    const handleResetToHome = () => {
      if (isVisible) {
        handleBack();
      }
    };

    window.addEventListener('agent:resetToHome', handleResetToHome);
    return () => {
      window.removeEventListener('agent:resetToHome', handleResetToHome);
    };
  }, [isVisible, handleBack]);



  return (
    <div
      className="flex-1 overflow-hidden bg-background flex flex-col"
      style={{ display: isVisible ? 'flex' : 'none' }}
    >
      <div className="relative flex-1 min-h-0 overflow-hidden flex flex-col">
        {currentChat ? (
          <ChatPanel
            key={currentChat.sessionId} // Force remount when sessionId changes
            currentChat={currentChat}
            onBack={handleBack}
            feature={feature}
            onLoadConversation={handleLoadConversation}
            initialMessageData={initialMessageData}
            onClearInitialData={() => setInitialMessageData(null)}
            onConversationChange={handleChatConversationChange}
            onTitleChange={handleChatTitleChange}
            onOpenSubView={setSubView}
          />
        ) : (
          <HomePanel
            onSendMessage={handleHomeUserSend}
            onLoadConversation={handleLoadConversation}
            initialValue={homeInitialValue}
            onOpenSubView={setSubView}
          />
        )}
        {subView === 'history' && (
          <HistoryPanel
            isOpen={true}
            onClose={() => setSubView(null)}
            onLoadConversation={handleLoadConversation}
            onNavigate={setSubView}
          />
        )}
        {subView === 'marketplace' && (
          <MarketplacePanel
            isOpen={true}
            onClose={() => setSubView(null)}
            onNavigate={setSubView}
          />
        )}
        {subView === 'account' && (
          <AccountPanel isOpen={true} onClose={() => setSubView(null)} onNavigate={setSubView} />
        )}
        {subView === 'setting' && (
          <SettingsPanel isOpen={true} onClose={() => setSubView(null)} onNavigate={setSubView} />
        )}

      </div>
    </div>
  );
}

// ─── AgentPanel ────────────────────────────────────────────────────────────

interface AgentPanelProps {
  initialConversationId?: string | null;
  onConversationChange?: (conversationId: string | null) => void;
  /** Title conversation đang hiển thị (null khi ở Home) — dùng cho tab 'Zen|<title>' ở CodeAgent. */
  onTitleChange?: (title: string | null) => void;
  /** Feature do module host chỉ định; bỏ trống thì lấy từ FeatureContext. */
  feature?: AgentFeature;
}

export function AgentPanel({
  initialConversationId,
  onConversationChange,
  onTitleChange,
  feature,
}: AgentPanelProps) {
  const firstViewKeyRef = useRef<string | null>(null);
  const [rootEl, setRootEl] = useState<HTMLElement | null>(null);
  const { activeFeature: contextFeature, emulateState, codeState, reconState } = useAgentFeature();
  const activeFeature = feature ?? contextFeature;
  const { activeTargetId, targetStates } = emulateState;
  const { currentProjectId } = codeState;
  const currentExplorerRoot = useCodeStore(
    (s) => s.projects.find((p) => p.id === currentProjectId)?.explorerRoot ?? null,
  );
  const { activeTargetId: reconActiveTargetId, targets: reconTargets } = reconState;
  const activeDesignId = useDesignStore((s) => s.activeDesignId);
  const currentTargetState = activeTargetId ? targetStates[activeTargetId] : null;
  const isTargetActive = currentTargetState?.isActive || false;
  const openedKeysRef = useRef<Set<string>>(new Set());
  const [, forceUpdate] = useState(0);

  // Xác định active key dựa trên feature
  const activeKey = useMemo(() => {
    let key: string | null = null;

    if (activeFeature === 'emulate' && activeTargetId && isTargetActive) {
      key = `emulate:${activeTargetId}`;
      // Set global context for conversation service
      (window as any).__activeFeature = 'emulate';
      (window as any).__activeTargetId = activeTargetId;
    } else if (activeFeature === 'code' && currentProjectId) {
      key = `code:${currentProjectId}`;
      // Set global context for conversation service
      (window as any).__activeFeature = 'code';
      (window as any).__currentProjectId = currentProjectId;
      // Workspace folder path — key hash dùng CHUNG với Zen (PathService).
      const project = useCodeStore.getState().projects.find((p) => p.id === currentProjectId);
      const root = project?.explorerRoot ?? project?.path;
      if (root) (window as any).__zenWorkspaceFolderPath = root;
    } else if (activeFeature === 'recon' && reconActiveTargetId) {
      key = `recon:${reconActiveTargetId}`;
      // Set global context for conversation service
      (window as any).__activeFeature = 'recon';
      (window as any).__activeTargetId = reconActiveTargetId;
    } else if (activeFeature === 'design' && activeDesignId) {
      key = `design:${activeDesignId}`;
      (window as any).__activeFeature = 'design';
      (window as any).__activeDesignId = activeDesignId;
    }
    return key;
  }, [
    activeFeature,
    activeTargetId,
    isTargetActive,
    currentProjectId,
    currentExplorerRoot,
    reconActiveTargetId,
    activeDesignId,
  ]);

  // Khi activeKey thay đổi, thêm vào openedKeys
  useEffect(() => {
    if (activeKey && !openedKeysRef.current.has(activeKey)) {
      openedKeysRef.current.add(activeKey);
      forceUpdate((n) => n + 1);
    }
  }, [activeKey]);

  // Cleanup keys không còn hợp lệ (target/project đã bị xóa)
  useEffect(() => {
    const keys = Array.from(openedKeysRef.current);
    let changed = false;
    for (const key of keys) {
      if (key.startsWith('emulate:')) {
        const targetId = key.slice('emulate:'.length);
        if (!targetStates[targetId]) {
          openedKeysRef.current.delete(key);
          changed = true;
        }
      }
      if (key.startsWith('recon:')) {
        const targetId = key.slice('recon:'.length);
        if (!reconTargets.find((t) => t.id === targetId)) {
          openedKeysRef.current.delete(key);
          changed = true;
        }
      }
      // code keys được giữ vĩnh viễn — project có thể bị xóa nhưng state vẫn trong memory
      // upgrade path: cleanup code keys khi project bị remove khỏi useCodeStore
    }
    if (changed) {
      forceUpdate((n) => n + 1);
    }
  }, [targetStates, reconTargets]);

  // Overlay checks
  const showGenericOverlay =
    activeFeature !== 'emulate' &&
    activeFeature !== 'code' &&
    activeFeature !== 'recon' &&
    activeFeature !== 'design';
  const showDesignOverlay = activeFeature === 'design' && !activeDesignId;
  const showEmulateOverlay = activeFeature === 'emulate' && (!activeTargetId || !isTargetActive);
  const showReconOverlay = activeFeature === 'recon' && !reconActiveTargetId;

  const renderEmulateOverlay = () => {
    const hasTarget = !!activeTargetId;
    return (
      <AgentOverlay
        title={hasTarget ? 'Start the target session' : 'Select a target to start'}
        description={
          hasTarget
            ? 'Click Start on the selected target to begin a CDP or MITM session and use the Agent'
            : 'Please select a target and start a CDP or MITM session to use the Agent'
        }
        icon={<MousePointer className="w-8 h-8 text-primary opacity-80" />}
      />
    );
  };

  return (
    <ProjectProvider>
      <AgentRootContext.Provider value={rootEl}>
        <div
          ref={setRootEl}
          className="flex flex-col bg-background rounded-xl overflow-hidden shadow-2xl h-full font-sans text-text-primary relative"
        >
          {/* Overlay cho feature không hỗ trợ */}
          {showGenericOverlay && <AgentOverlay featureName={activeFeature || undefined} />}

          {/* Overlay cho emulate khi chưa có target */}
          {showEmulateOverlay && renderEmulateOverlay()}

          {/* Overlay cho recon khi chưa có target */}
          {showReconOverlay && (
            <AgentOverlay
              title="Select a target to start"
              description="Please select a target from the left panel to use the Agent"
              icon={<MousePointer className="w-8 h-8 text-primary opacity-80" />}
            />
          )}

          {showDesignOverlay && (
            <AgentOverlay
              title="Open a design to start"
              description="Please open or create a design to use the Design Agent"
              icon={<MousePointer className="w-8 h-8 text-primary opacity-80" />}
            />
          )}

          {/* Keep-alive views — tất cả đều mounted, chỉ activeKey hiển thị */}
          {!showGenericOverlay && !showEmulateOverlay && (
            <div className="flex-1 overflow-hidden bg-background flex flex-col">
              {(() => {
                const keys = Array.from(openedKeysRef.current);
                return keys.map((key) => {
                  const feature = key.startsWith('emulate:')
                    ? 'emulate'
                    : key.startsWith('recon:')
                      ? 'recon'
                      : key.startsWith('design:')
                        ? 'design'
                        : 'code';
                  const isVisible = key === activeKey;
                  if (firstViewKeyRef.current === null) firstViewKeyRef.current = key;
                  return (
                    <AgentView
                      key={key}
                      feature={feature}
                      isVisible={isVisible}
                      initialConversationId={
                        key === firstViewKeyRef.current ? initialConversationId : undefined
                      }
                      onConversationChange={onConversationChange}
                      onTitleChange={onTitleChange}
                    />
                  );
                });
              })()}
            </div>
          )}
        </div>
      </AgentRootContext.Provider>
    </ProjectProvider>
  );
}
