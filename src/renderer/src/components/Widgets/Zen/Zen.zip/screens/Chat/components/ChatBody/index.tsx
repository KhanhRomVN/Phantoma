import React, { useRef, useEffect, useMemo } from 'react';
/**
 * ------------------------------------------------------------------
 * ChatBody
 * ------------------------------------------------------------------
 * Component chính hiển thị danh sách messages trong chat.
 * Xử lý parsing, pagination, scroll behavior, và tool actions.
 *
 * Main features:
 * - Parse AI response thành groups hiển thị
 * - Phân trang messages với LoadMore
 * - Auto-scroll khi có message mới
 * - Xử lý tool actions (execute/approve/reject)
 * ------------------------------------------------------------------
 */

// ─── Imports ────────────────────────────────────────────────────────────
// ── Utils ──

import { cn } from '@renderer/utils/cn';

// ── Types ──
import { parseAIResponse, ParsedResponse, ToolAction } from '../../services/responseParser';
import { Message } from '../../types/message';

// ── Constants ──
import { EXECUTION_STATUS, TOOL_ACTION_TYPES, TERMINAL_STATUS } from '../../constants/tag-registry';
import { DEFAULT_TOOL_FORMAT } from '../../services/tool-format-parsers';
import type { ToolFormatId } from '../../services/tool-format-parsers/types';

// ── Hooks ──
import { useCollapseSections } from '../../hooks/ui/useCollapseSections';
import { useToolActions } from '../../hooks/tools/useToolActions';
import { useScrollBehavior } from '../../hooks/ui/useScrollBehavior';
import { useMessagePagination } from '../../hooks/ui/useMessagePagination';

// ── Context ──

// ── Components ──
import ChatBodySkeleton from './ChatBodySkeleton';
import { LoadMoreButton } from './LoadMoreButton';
import ModelInfoBar from './ModelInfoBar';
import SearchBar from './SearchBar';
import ContinuingIndicator from './ContinuingIndicatorBox';
import ProcessingIndicator from './ProcessingIndicator';
import UserMessageBox from './UserMessageBox';
import AIMessageBox from './AIMessageBox';
import { useWorkflowAgentSync } from '@renderer/components/Widgets/Zen/context/WorkflowAgentContext';

// ─── Types ──────────────────────────────────────────────────────────────
interface ChatBodyProps {
  messages: Message[];
  isProcessing: boolean;
  onSendToolRequest?: (
    action: ToolAction | ToolAction[],
    message: Message,
    isAutoTrigger?: boolean,
    actionType?: (typeof TOOL_ACTION_TYPES)[keyof typeof TOOL_ACTION_TYPES],
  ) => void;
  onToolAction?: (
    actionId: string,
    actionType: (typeof TOOL_ACTION_TYPES)[keyof typeof TOOL_ACTION_TYPES],
    toolName?: string,
  ) => void;
  onSendMessage?: (
    content: string,
    files?: any[],
    model?: any,
    account?: any,
    skipFirstRequestLogic?: boolean,
    actionIds?: string[],
    uiHidden?: boolean,
  ) => void | Promise<void>;
  onSelectOption?: (messageId: string, option: string) => void;
  firstRequestMessageId?: string;
  executionState?: {
    total: number;
    completed: number;
    status: (typeof EXECUTION_STATUS)[keyof typeof EXECUTION_STATUS];
  };
  toolOutputs?: Record<string, { output: string; isError: boolean }>;
  terminalStatus?: Record<string, (typeof TERMINAL_STATUS)[keyof typeof TERMINAL_STATUS]>;
  onLoadConversation?: (conversationId: string, tabId: number, folderPath: string | null) => void;
  onRevertConversation?: (messageId: string, timestamp: number) => void;
  onAutoScrollPausedChange?: (paused: boolean) => void;
  scrollToBottomRef?: React.MutableRefObject<(() => void) | null>;
  isContinuing?: boolean;
  onGitConfirm?: (items: any[]) => void;
  onGitCancel?: () => void;
  gitStatusItems?: any[];
  gitStatusBranch?: string;
  isGitProcessing?: boolean;
  isGitStatusVisible?: boolean;
  onBackToHome?: (summary: string) => void;
  isLoadingConversation?: boolean;
  feature?: string | null;
  toolFormat?: ToolFormatId;
}

export interface ExtendedChatBodyProps extends ChatBodyProps {
  executionState?: {
    total: number;
    completed: number;
    status: (typeof EXECUTION_STATUS)[keyof typeof EXECUTION_STATUS];
  };
  toolOutputs?: Record<string, { output: string; isError: boolean }>;
  terminalStatus?: Record<string, (typeof TERMINAL_STATUS)[keyof typeof TERMINAL_STATUS]>;
  activeTerminalIds?: Set<string>;
  attachedTerminalIds?: Set<string>;
  conversationId?: string;
  previousAssistantMessage?: Message;
  isRestored?: boolean;
  onContinue?: () => void;
  hasInitialMessage?: boolean;
  singleLineReviewActions?: Record<string, { action: any; actionId: string; messageId: string }>;
  onConfirmSingleLineAction?: (actionId: string) => void;
  onRejectSingleLineAction?: (actionId: string) => void;
  isSearchOpen?: boolean;
  searchQuery?: string;
  onSearchQueryChange?: (q: string) => void;
  onCloseSearch?: () => void;
  onApproveDangerousAction?: (actionId: string) => void;
  onRejectDangerousAction?: (actionId: string) => void;
}

// ─────────────────────────────────────────────────────────────────────────────
// Error Boundary for Message Rendering
// ─────────────────────────────────────────────────────────────────────────────

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class MessageBoxErrorBoundary extends React.Component<
  { children: React.ReactNode },
  ErrorBoundaryState
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error('[MessageBox] Render error caught:', error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="p-3 px-4 flex flex-col gap-2">
          <div className="flex items-start justify-between w-full">
            <div className="flex items-start gap-2 flex-1 min-w-0">
              <div
                className="relative w-4 h-4 shrink-0 flex items-center justify-center mt-0.5"
                title="Error - Render failed"
              >
                <div className="w-2 h-2 rounded-full bg-error" />
              </div>
            </div>

            <div className="shrink-0 ml-2">
              <span className="text-[12px] font-semibold text-error uppercase tracking-[0.5px]">
                ERROR
              </span>
            </div>
          </div>

          {this.state.error && (
            <div className="py-3 px-4 rounded-md border border-error/30 bg-error/5">
              <pre className="text-[12px] text-text-secondary m-0 whitespace-pre-wrap break-words max-h-[120px] overflow-y-auto font-mono">
                {this.state.error.message}
              </pre>
            </div>
          )}
        </div>
      );
    }

    return <>{this.props.children}</>;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// MessageBox Props Interface
// ─────────────────────────────────────────────────────────────────────────────

interface MessageBoxProps {
  message: Message;
  parsedContent: ParsedResponse;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  /** Feature/module hiện tại (code/recon/emulate) để chọn renderer đúng module. */
  feature?: string | null;
  clickedActions: Set<string>;
  failedActions?: Set<string>;
  rejectedActions?: Set<string>;
  onToolClick: (
    action: any,
    message: Message,
    index: number,
    type: (typeof TOOL_ACTION_TYPES)[keyof typeof TOOL_ACTION_TYPES],
  ) => void;
  requestNumber?: number | null;
  executionState?: {
    total: number;
    completed: number;
    status: (typeof EXECUTION_STATUS)[keyof typeof EXECUTION_STATUS];
  };
  isLastMessage?: boolean;
  hasNextAssistantMessage?: boolean;
  toolOutputs?: Record<string, { output: string; isError: boolean }>;
  terminalStatus?: Record<string, (typeof TERMINAL_STATUS)[keyof typeof TERMINAL_STATUS]>;
  nextUserMessage?: Message;
  allMessages?: Message[];
  activeTerminalIds?: Set<string>;
  attachedTerminalIds?: Set<string>;
  conversationId?: string;
  previousAssistantMessage?: Message;
  isGenerating?: boolean;
  onSendMessage?: (
    content: string,
    files?: any[],
    model?: any,
    account?: any,
    skipLogic?: boolean,
    actionIds?: string[],
    uiHidden?: boolean,
  ) => void;
  onSelectOption?: (messageId: string, option: string) => void;
  onRevertConversation?: (messageId: string, timestamp: number) => void;
  singleLineReviewActions?: Record<string, { action: any; actionId: string; messageId: string }>;
  onConfirmSingleLineAction?: (actionId: string) => void;
  onRejectSingleLineAction?: (actionId: string) => void;
  onGitConfirm?: (items: any[]) => void;
  onGitCancel?: () => void;
  gitStatusItems?: any[];
  gitStatusBranch?: string;
  isGitProcessing?: boolean;
  isGitStatusVisible?: boolean;
  onBackToHome?: (summary: string) => void;
  responseNumber?: number | null;
  onRetryRequest?: (messageId: string) => void;
  isRestored?: boolean;
  onApproveDangerousAction?: (actionId: string) => void;
  onRejectDangerousAction?: (actionId: string) => void;
}

// ─────────────────────────────────────────────────────────────────────────────
// MessageBox Component (Inline - previously in MessageBox.tsx)
// ─────────────────────────────────────────────────────────────────────────────

const MessageBoxComponent: React.FC<MessageBoxProps> = (props) => {
  const { message, onRevertConversation, onSendMessage, conversationId } = props;
  const workflowSync = useWorkflowAgentSync();

  if (message.role === 'user') {
    const incoming = workflowSync?.renderIncomingMessage?.(message);
    if (incoming) return <>{incoming}</>;
    return (
      <UserMessageBox
        message={message}
        conversationId={conversationId}
        onRevertConversation={onRevertConversation}
        onSendMessage={onSendMessage}
      />
    );
  }

  return <AIMessageBox {...props} />;
};

// Memoize to prevent unnecessary re-renders
const MessageBox = React.memo(MessageBoxComponent, (prevProps, nextProps) => {
  const isStreaming = prevProps.isGenerating === true && nextProps.isGenerating === true;

  if (isStreaming) {
    const streamingPropsEqual =
      prevProps.message.id === nextProps.message.id &&
      prevProps.message.content === nextProps.message.content &&
      prevProps.message.thinking === nextProps.message.thinking &&
      prevProps.clickedActions === nextProps.clickedActions &&
      prevProps.failedActions === nextProps.failedActions &&
      prevProps.rejectedActions === nextProps.rejectedActions;
    return streamingPropsEqual;
  }

  const propsAreEqual =
    prevProps.message.id === nextProps.message.id &&
    prevProps.message.content === nextProps.message.content &&
    prevProps.message.thinking === nextProps.message.thinking &&
    prevProps.clickedActions === nextProps.clickedActions &&
    prevProps.failedActions === nextProps.failedActions &&
    prevProps.rejectedActions === nextProps.rejectedActions &&
    prevProps.isGenerating === nextProps.isGenerating &&
    prevProps.toolOutputs === nextProps.toolOutputs;
  return propsAreEqual;
});

// Wrap with error boundary
const MessageBoxWithErrorBoundary: React.FC<MessageBoxProps> = (props) => (
  <MessageBoxErrorBoundary>
    <MessageBox {...props} />
  </MessageBoxErrorBoundary>
);

// ─────────────────────────────────────────────────────────────────────────────
// ChatBody Component
// ─────────────────────────────────────────────────────────────────────────────

const ChatBodyInternal: React.FC<ExtendedChatBodyProps> = ({
  messages,
  isProcessing,
  onSendToolRequest,
  onSendMessage,
  executionState,
  toolOutputs,
  terminalStatus,
  firstRequestMessageId,
  activeTerminalIds,
  attachedTerminalIds,
  conversationId,
  onToolAction,
  onSelectOption,
  isRestored = false,
  isContinuing = false,
  onContinue,
  hasInitialMessage = false,
  onRevertConversation,
  onAutoScrollPausedChange,
  scrollToBottomRef,
  singleLineReviewActions,
  onConfirmSingleLineAction,
  onRejectSingleLineAction,
  isSearchOpen = false,
  searchQuery = '',
  onSearchQueryChange,
  onCloseSearch,
  onGitConfirm,
  onGitCancel,
  gitStatusItems,
  gitStatusBranch,
  isGitProcessing,
  isGitStatusVisible = true,
  onBackToHome,
  isLoadingConversation = false,
  feature,
  toolFormat = DEFAULT_TOOL_FORMAT,
  onApproveDangerousAction,
  onRejectDangerousAction,
}: ExtendedChatBodyProps) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const bodyRef = useRef<HTMLDivElement>(null);

  const { hiddenCount, loadMore, loadAll, hasHiddenMessages } = useMessagePagination({
    messages,
    messagesPerPage: 10,
  });

  const parseCacheRef = useRef<Map<string, ParsedResponse>>(new Map());
  const lastParsedMessagesRef = useRef<any[]>([]);

  // Clear cache when messages array is reset (empty)
  useEffect(() => {
    if (messages.length === 0) {
      parseCacheRef.current.clear();
      lastParsedMessagesRef.current = [];
    }
  }, [messages.length]);

  const parsedMessages = useMemo(() => {
    if (messages.length > 0 && messages[0].parsed !== undefined) {
      const messagesUnchanged =
        lastParsedMessagesRef.current.length === messages.length &&
        messages.every(
          (msg, i) =>
            msg.id === lastParsedMessagesRef.current[i]?.id &&
            msg.content === lastParsedMessagesRef.current[i]?.content,
        );

      if (messagesUnchanged) {
        return lastParsedMessagesRef.current;
      }

      lastParsedMessagesRef.current = messages;
      return messages;
    }

    const cache = parseCacheRef.current;

    const result = messages.map((msg) => {
      const contentCacheKey = `${toolFormat}::${msg.content}`;
      const cached = cache.get(contentCacheKey);
      if (!cached || cached === undefined) {
        const parsed = parseAIResponse(msg.content, toolFormat, feature);
        cache.set(contentCacheKey, parsed);
      }
      return { ...msg, parsed: cache.get(contentCacheKey)! };
    });

    lastParsedMessagesRef.current = result;
    return result;
  }, [messages, feature, toolFormat]);

  const { collapsedSections, toggleCollapse } = useCollapseSections();
  const { clickedActions, handleToolClick, failedActions, rejectedActions } = useToolActions({
    onSendToolRequest,
    onToolAction,
    parsedMessages,
    isProcessing,
    isRestored,
  });
  const { autoScrollPaused, scrollToBottom } = useScrollBehavior(
    messagesEndRef as any,
    bodyRef as any,
    messages,
    isProcessing,
  );

  const prevPausedRef = useRef(false);
  useEffect(() => {
    if (autoScrollPaused !== prevPausedRef.current) {
      prevPausedRef.current = autoScrollPaused;
      onAutoScrollPausedChange?.(autoScrollPaused);
    }
  }, [autoScrollPaused, onAutoScrollPausedChange]);

  useEffect(() => {
    if (scrollToBottomRef) scrollToBottomRef.current = scrollToBottom;
  }, [scrollToBottom, scrollToBottomRef]);

  const hasUnexecutedAutoActions = useMemo(() => {
    if (!isRestored || messages.length === 0) return false;
    const lastMessage = messages[messages.length - 1];
    if (lastMessage.role !== 'assistant') return false;
    const parsed = parseAIResponse(lastMessage.content, toolFormat, feature);
    if (!parsed.actions || parsed.actions.length === 0) return false;
    const firstPendingAction = parsed.actions.find((_action: any, idx: number) => {
      const actionId = `${lastMessage.id}-action-${idx}`;
      const hasOutput = toolOutputs && toolOutputs[actionId];
      const isClicked = clickedActions.has(actionId);
      return !hasOutput && !isClicked;
    });
    if (!firstPendingAction) return false;
    return false;
  }, [messages, isRestored, toolOutputs, clickedActions, feature, toolFormat]);

  const visibleMessages = useMemo(() => {
    const filtered = messages.filter((msg) => !msg.uiHidden && !msg.isCancelled);
    return filtered;
  }, [messages, firstRequestMessageId]);

  const lastAssistantIndex = useMemo(() => {
    for (let i = visibleMessages.length - 1; i >= 0; i--) {
      if (visibleMessages[i].role === 'assistant') return i;
    }
    return -1;
  }, [visibleMessages]);

  const isResponding = useMemo(() => {
    if (!isProcessing || visibleMessages.length === 0) return false;
    const lastMessage = visibleMessages[visibleMessages.length - 1];
    if (lastMessage.role !== 'assistant') return false;
    const parsedMessage = parsedMessages.find((pm) => pm.id === lastMessage.id);
    if (!parsedMessage || !parsedMessage.parsed) return false;
    const parsed = parsedMessage.parsed;

    if (lastMessage.thinking && lastMessage.thinking.trim().length > 0) {
      return false;
    }

    const hasThinkingBlock =
      parsed.contentBlocks && parsed.contentBlocks.some((b: any) => b.type === 'thinking');
    if (hasThinkingBlock) {
      return false;
    }

    const hasText = parsed.displayText && parsed.displayText.trim().length > 0;
    if (hasText) {
      return false;
    }

    const hasActions = parsed.actions && parsed.actions.length > 0;
    if (hasActions) {
      return false;
    }

    const hasOtherBlocks =
      parsed.contentBlocks &&
      parsed.contentBlocks.some((b: any) => {
        if (b.type === 'thinking') {
          return false;
        }
        switch (b.type) {
          case 'tool':
            return true;
          case 'code':
          case 'file':
          case 'markdown':
            return (b as any).content?.trim().length > 0;
          default:
            return false;
        }
      });

    if (hasOtherBlocks) {
      return false;
    }

    return true;
  }, [isProcessing, visibleMessages, parsedMessages]);

  return (
    <div
      ref={bodyRef}
      className={cn(
        'chat-body-scroll bg-background flex-1 overflow-y-auto overflow-x-hidden py-4 flex flex-col gap-2 text-[15px] relative',
        visibleMessages.length > 0 ? 'pb-[200px]' : 'pb-4',
      )}
      style={{ paddingInline: 'max(16px, calc((100% - 680px) / 2 + 16px))' }}
    >
      {isLoadingConversation ? (
        <>
          <ChatBodySkeleton />
        </>
      ) : (
        <>
          {isSearchOpen && (
            <SearchBar
              searchQuery={searchQuery}
              onSearchQueryChange={onSearchQueryChange}
              onCloseSearch={onCloseSearch}
              bodyRef={bodyRef as any}
            />
          )}

          {hasHiddenMessages && (
            <LoadMoreButton hiddenCount={hiddenCount} onLoadMore={loadMore} onLoadAll={loadAll} />
          )}

          {(() => {
            let assistantResponseCount = 0;
            return visibleMessages.map((message, index) => {
              if (message.content?.startsWith('__MODEL_SWITCH__::')) {
                return <ModelInfoBar key={message.id} message={message} />;
              }

              const parsedMessage = parsedMessages.find((pm) => pm.id === message.id);
              if (!parsedMessage || !parsedMessage.parsed) return null;
              const parsedContent = parsedMessage.parsed;

              if (message.role === 'assistant') {
                assistantResponseCount++;
              }
              const currentResponseNumber =
                message.role === 'assistant' ? assistantResponseCount : null;

              const nextUserMessage = messages
                .slice(messages.findIndex((m) => m.id === message.id) + 1)
                .find((m) => m.role === 'user');
              const previousAssistantMessage = messages
                .slice(
                  0,
                  messages.findIndex((m) => m.id === message.id),
                )
                .reverse()
                .find((m) => m.role === 'assistant');

              const nextVisibleMessage = visibleMessages[index + 1];
              const hasNextAssistantMessage = nextVisibleMessage?.role === 'assistant';

              return (
                <MessageBoxWithErrorBoundary
                  key={message.id}
                  message={message}
                  parsedContent={parsedContent}
                  nextUserMessage={nextUserMessage}
                  responseNumber={currentResponseNumber}
                  isGenerating={isProcessing && index === visibleMessages.length - 1}
                  isCollapsed={
                    message.role === 'user' ? collapsedSections.has(`prompt-${message.id}`) : false
                  }
                  onToggleCollapse={() => toggleCollapse(`prompt-${message.id}`)}
                  clickedActions={clickedActions}
                  failedActions={failedActions}
                  rejectedActions={rejectedActions}
                  onToolClick={handleToolClick}
                  executionState={executionState}
                  isLastMessage={
                    message.role === 'assistant' &&
                    (index === visibleMessages.length - 1 || index === lastAssistantIndex) &&
                    hasNextAssistantMessage === false
                  }
                  hasNextAssistantMessage={hasNextAssistantMessage}
                  toolOutputs={toolOutputs}
                  terminalStatus={terminalStatus}
                  allMessages={messages}
                  activeTerminalIds={activeTerminalIds}
                  attachedTerminalIds={attachedTerminalIds}
                  conversationId={conversationId}
                  previousAssistantMessage={previousAssistantMessage}
                  onSendMessage={onSendMessage}
                  onSelectOption={onSelectOption}
                  onRevertConversation={onRevertConversation}
                  singleLineReviewActions={singleLineReviewActions}
                  onConfirmSingleLineAction={onConfirmSingleLineAction}
                  onRejectSingleLineAction={onRejectSingleLineAction}
                  onGitConfirm={onGitConfirm}
                  onGitCancel={onGitCancel}
                  gitStatusItems={gitStatusItems}
                  gitStatusBranch={gitStatusBranch}
                  isGitProcessing={isGitProcessing}
                  isGitStatusVisible={isGitStatusVisible}
                  onBackToHome={onBackToHome}
                  isRestored={isRestored}
                  onApproveDangerousAction={onApproveDangerousAction}
                  onRejectDangerousAction={onRejectDangerousAction}
                  feature={feature}
                  onRetryRequest={(messageId: string) => {
                    const msgIndex = messages.findIndex((m) => m.id === messageId);
                    if (msgIndex <= 0) return;

                    let prevUserMsg: Message | null = null;
                    for (let i = msgIndex - 1; i >= 0; i--) {
                      if (messages[i].role === 'user') {
                        prevUserMsg = messages[i];
                        break;
                      }
                    }

                    if (!prevUserMsg) return;

                    if (onRevertConversation) {
                      onRevertConversation(messageId, message.timestamp);
                    }

                    if (onSendMessage && prevUserMsg.rawRequest) {
                      setTimeout(() => {
                        const rawReq = prevUserMsg!.rawRequest || '';
                        const userContentMatch = rawReq.match(
                          /<zen-user-content>\n?([\s\S]*?)\n?<\/zen-user-content>/,
                        );

                        let contentToSend: string;
                        let shouldSkipLogic: boolean;

                        if (userContentMatch) {
                          contentToSend = userContentMatch[1];
                          shouldSkipLogic = false;
                        } else {
                          contentToSend = rawReq;
                          shouldSkipLogic = true;
                        }

                        onSendMessage(
                          contentToSend,
                          prevUserMsg!.uploadedFiles,
                          undefined,
                          undefined,
                          shouldSkipLogic,
                        );
                      }, 100);
                    }
                  }}
                />
              );
            });
          })()}

          {(() => {
            const lastMessage = visibleMessages[visibleMessages.length - 1];
            const isRenderingThinking =
              lastMessage && lastMessage.role === 'assistant' && isProcessing;

            if (!isRenderingThinking) {
              return null;
            }

            return null;
          })()}

          {hasUnexecutedAutoActions && onContinue && (
            <div className="my-3 flex">
              <button
                onClick={onContinue}
                className={cn(
                  'inline-flex items-center justify-center gap-1.5 px-4 py-1.5 rounded-md cursor-pointer text-[12px] font-semibold uppercase tracking-[0.5px] h-7 box-border transition-all duration-200',
                  'bg-primary/15 text-primary border border-primary/30',
                )}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor =
                    'color-mix(in srgb, rgb(10, 132, 255) 25%, transparent)';
                  e.currentTarget.style.borderColor =
                    'color-mix(in srgb, rgb(10, 132, 255) 50%, transparent)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor =
                    'color-mix(in srgb, rgb(10, 132, 255) 15%, transparent)';
                  e.currentTarget.style.borderColor =
                    'color-mix(in srgb, rgb(10, 132, 255) 30%, transparent)';
                }}
              >
                <span className="codicon codicon-play text-[13px] inline-flex items-center justify-center" />
                <span>Continue Task</span>
              </button>
            </div>
          )}

          {isContinuing && <ContinuingIndicator />}

          {(isProcessing || hasInitialMessage) && (
            <ProcessingIndicator isResponding={isResponding} />
          )}

          <div ref={messagesEndRef} />
          <style>{`
        .chat-body-scroll::-webkit-scrollbar {
          width: 13px;
          height: 4px;
        }
        .chat-body-scroll::-webkit-scrollbar-track {
          background: transparent;
        }
        .chat-body-scroll::-webkit-scrollbar-thumb {
          background: rgb(106, 122, 154, 0.4);
          border-radius: 4px;
          min-height: 48px;
        }
        .chat-body-scroll::-webkit-scrollbar-thumb:hover {
          background: rgb(106, 122, 154, 0.6);
        }
      `}</style>
        </>
      )}
    </div>
  );
};

export default ChatBodyInternal;
