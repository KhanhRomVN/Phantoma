import React, { useMemo, useRef, useState, useEffect } from 'react';
/**
 * ------------------------------------------------------------------
 * TagHeader
 * ------------------------------------------------------------------
 * Header component cho tool action blocks trong chat.
 * Hiển thị title, status dot, file path, và các action buttons.
 *
 * Main features:
 * - Hiển thị status color dựa trên trạng thái tool
 * - Collapse/expand cho tool block
 * - File path clickable với FileIcon
 * ------------------------------------------------------------------
 */

// ─── Imports ────────────────────────────────────────────────────────────
// ── Utils ──
import { cn } from '@renderer/utils/cn';
import { $ } from '@renderer/utils/color';
import { buildStatusTooltip } from '../../../utils/status-tooltip-builder';

// ─── Types ─────────────────────────────────────────────────────���────────
interface TagHeaderProps {
  title: React.ReactNode;
  subTitle?: React.ReactNode;
  subTitleClassName?: string;
  statusColor?: string;
  diffStats?: {
    added: number;
    removed: number;
  };
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
  onClick?: () => void;
  icon?: React.ReactNode;
  headerActions?: React.ReactNode;
  isPartial?: boolean;
  /** File or folder path to display in the header */
  path?: string;
  /** Icon hiển thị trước path ở dòng 2 */
  pathIcon?: React.ReactNode;
  /** Callback when path is clicked (separate from header click) */
  onPathClick?: (path: string) => void;
  /** Giảm một nửa khoảng cách giữa dòng tiêu đề và dòng path */
  compactPath?: boolean;
  /** Optional custom tooltip text for the status dot */
  statusTooltip?: string;
  /** Whether this action is waiting for approval */
  isWaitingApproval?: boolean;
  /** Whether this action has an error */
  isError?: boolean;
  /** Tool type for context-specific tooltips */
  toolType?: string;
  /** Additional metadata for tooltip (e.g., line count, match count) */
  tooltipMeta?: {
    lineCount?: number;
    lineRange?: string;
    matchCount?: number;
    fileCount?: number;
  };

  /** Callback when dot is clicked (for raw view toggle, etc.) */
  onDotClick?: () => void;
}

// Smart path truncation: dynamically truncate middle folders based on available width
const truncatePath = (fullPath: string, maxLength: number = 35): string => {
  if (!fullPath) return '';

  if (fullPath.length <= maxLength) {
    return fullPath;
  }

  const parts = fullPath.split('/');

  if (parts.length <= 2) {
    return fullPath;
  }

  const fileName = parts[parts.length - 1];
  const rootFolder = parts[0];

  let result = `${rootFolder}/.../${fileName}`;
  let currentLength = result.length;

  if (currentLength >= maxLength) {
    return result;
  }

  let rightIndex = parts.length - 2;
  const foldersToAdd: string[] = [];

  while (rightIndex > 0) {
    const folderToTest = parts[rightIndex];
    const testResult = `${rootFolder}/.../${[...foldersToAdd, folderToTest].reverse().join('/')}/${fileName}`;

    if (testResult.length <= maxLength) {
      foldersToAdd.push(folderToTest);
      result = testResult;
      currentLength = testResult.length;
      rightIndex--;
    } else {
      break;
    }
  }

  return result;
};

export const TagHeader: React.FC<TagHeaderProps> = ({
  title,
  subTitle,
  subTitleClassName,
  statusColor,
  diffStats,
  onToggleCollapse,
  onClick,
  icon,
  headerActions,
  isPartial,
  path,
  pathIcon,
  onPathClick,
  compactPath,
  statusTooltip,
  isWaitingApproval,
  isError,
  toolType,
  tooltipMeta,
  onDotClick,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const pathContainerRef = useRef<HTMLDivElement>(null);
  const pathSpanRef = useRef<HTMLSpanElement>(null);
  const [containerWidth, setContainerWidth] = useState<number>(0);
  const [pathContainerWidth, setPathContainerWidth] = useState<number>(0);
  const [, setPathSpanWidth] = useState<number>(0);

  useEffect(() => {
    const styleId = 'circle-ring-spin-animation';
    if (!document.getElementById(styleId)) {
      const style = document.createElement('style');
      style.id = styleId;
      style.textContent = `
        @keyframes circle-ring-spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `;
      document.head.appendChild(style);
    }
  }, []);

  useEffect(() => {
    if (!containerRef.current) return;
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const newWidth = entry.contentRect.width;
        setContainerWidth(newWidth);
      }
    });
    observer.observe(containerRef.current);
    const initialWidth = containerRef.current.offsetWidth || 0;
    setContainerWidth(initialWidth);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!pathContainerRef.current) return;
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const newWidth = entry.contentRect.width;
        setPathContainerWidth(newWidth);
      }
    });
    observer.observe(pathContainerRef.current);
    const initialWidth = pathContainerRef.current.offsetWidth || 0;
    setPathContainerWidth(initialWidth);
    return () => observer.disconnect();
  }, []);

  const maxLength = useMemo(() => {
    if (containerWidth === 0) {
      return 999;
    }

    const availableWidth =
      pathContainerWidth > 0 ? pathContainerWidth - 24 : Math.max(containerWidth - 80, 100);

    const chars = Math.floor(availableWidth / 6.5);
    const result = Math.max(chars, 30);

    return result;
  }, [containerWidth, pathContainerWidth]);

  const displayPath = useMemo(() => {
    if (!path) return '';
    const truncated = truncatePath(path, maxLength);
    return truncated;
  }, [path, maxLength]);

  useEffect(() => {
    if (!pathSpanRef.current) return;
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const newWidth = entry.contentRect.width;
        setPathSpanWidth(newWidth);
      }
    });
    observer.observe(pathSpanRef.current);
    const initialWidth = pathSpanRef.current.offsetWidth || 0;
    setPathSpanWidth(initialWidth);
    return () => observer.disconnect();
  }, [displayPath]);

  const pathColor = $('--text-secondary');

  const getStatusTooltip = useMemo(() => {
    return buildStatusTooltip({
      customTooltip: statusTooltip,
      isError,
      isPartial,
      isWaitingApproval,
      statusColor,
      toolType,
      diffStats,
      tooltipMeta,
    });
  }, [
    statusTooltip,
    isError,
    isPartial,
    isWaitingApproval,
    statusColor,
    toolType,
    diffStats,
    tooltipMeta,
  ]);

  return (
    <div
      ref={containerRef}
      className={cn(
        'pt-1 flex items-start justify-between w-full',
        onClick || onToggleCollapse ? 'cursor-pointer' : 'cursor-default',
      )}
      onClick={onClick || onToggleCollapse}
    >
      <div className="flex-1 min-w-0">
        <div>
          <div className="mt-px flex flex-col gap-0.5 flex-1 min-w-0 w-full max-w-full overflow-hidden">
            <div className="flex items-start gap-2 flex-nowrap">
              {/* Left column: CircleDot + CircleRing */}
              {statusColor && (
                <div
                  className={cn(
                    'relative w-4 h-4 shrink-0 flex items-center justify-center mt-0.5',
                    onDotClick ? 'cursor-pointer' : 'cursor-default',
                  )}
                  title={getStatusTooltip}
                  onClick={(e) => {
                    e.stopPropagation();
                    if (onDotClick) {
                      onDotClick();
                    }
                  }}
                >
                  {/* CircleRing */}
                  <div
                    style={{
                      position: 'absolute',
                      width: '16px',
                      height: '16px',
                      borderRadius: '50%',
                      ...(!isPartial && {
                        border: `2px solid ${statusColor}`,
                        opacity: 0.4,
                      }),
                      ...(isPartial && {
                        borderWidth: '2px',
                        borderStyle: 'solid',
                        borderRightColor: statusColor,
                        borderBottomColor: statusColor,
                        borderLeftColor: statusColor,
                        borderTopColor: 'transparent',
                        animation: 'circle-ring-spin 1s linear infinite',
                        opacity: 0.8,
                      }),
                    }}
                  />
                  {/* CircleDot */}
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: statusColor }} />
                </div>
              )}

              {/* Right column: All other content */}
              <div className="flex-1 min-w-0 flex flex-col gap-0.5 mt-0.5">
                <div className="flex items-center gap-1.5 flex-wrap">

                  {icon && <span className="flex items-center">{icon}</span>}
                  {typeof title === 'string' ? (
                    <span>{title}</span>
                  ) : (
                    <div className="contents">{title}</div>
                  )}
                </div>

                {displayPath && path && (
                  <div
                    ref={pathContainerRef}
                    className={`flex justify-start items-center pl-5 pr-1 relative w-full max-w-full overflow-hidden ${compactPath ? 'pt-0.5 mt-0' : 'pt-1 mt-0.5'}`}
                  >
                    {/* Corner line: vertical + horizontal L-shape */}
                    <div
                      className={`absolute left-0 top-0 w-4 border-l border-b border-text-secondary/20 ${compactPath ? 'h-2.5' : 'h-3'}`}
                    />
                    {pathIcon}
                    <span
                      ref={pathSpanRef}
                      className="text-[11px] opacity-60 font-mono whitespace-nowrap overflow-hidden text-ellipsis rounded-sm transition-[text-decoration] duration-150 cursor-default no-underline flex items-center gap-1 shrink min-w-0"
                      style={{ color: pathColor }}
                      title={path}
                      onClick={(e) => {
                        e.stopPropagation();
                        if (onPathClick && path) {
                          onPathClick(path);
                        }
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.textDecoration = 'underline';
                        e.currentTarget.style.textDecorationColor = $('--primary');
                        e.currentTarget.style.textUnderlineOffset = '2px';
                        e.currentTarget.style.cursor = 'pointer';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.textDecoration = 'none';
                        e.currentTarget.style.cursor = 'default';
                      }}
                    >
                      {displayPath}
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
        {(subTitle || diffStats) && (
          <div className={subTitleClassName || ''}>
            {diffStats ? (
              <>
                <span className="flex gap-1.5 items-center">
                  <span className="text-success">+{diffStats.added}</span>
                  <span className="text-error">-{diffStats.removed}</span>
                  <span>lines</span>
                </span>
              </>
            ) : (
              subTitle
            )}
          </div>
        )}
      </div>
      <div className="shrink-0 ml-2" onClick={(e) => e.stopPropagation()}>
        {headerActions}
      </div>
    </div>
  );
};
