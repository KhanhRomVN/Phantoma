import React, { useState, useCallback, useEffect, useRef } from 'react';

/**
 * ------------------------------------------------------------------
 * QuestionRenderer
 * ------------------------------------------------------------------
 * Renderer cho block câu hỏi/tùy chọn.
 * Xử lý cả định dạng tùy chọn đơn và nhiều câu hỏi.
 *
 * Main features:
 * - Render QuestionAnswerBlock với questions/options
 * - Hỗ trợ disabled state
 * ------------------------------------------------------------------
 */

// ─── Imports ────────────────────────────────────────────────────────────
// ── Types ──
import { Question, QuestionAnswer, QuestionType } from '../../../../types/message';
import { QUESTION_TRANSITION_DELAY } from '../../../../constants/ui';

// ── Utils ──
import { cn } from '@renderer/utils/cn';
import { $ } from '@renderer/utils/color';

// ── Components ──
import { TagHeader } from '../TagHeader';
import { Button } from '@renderer/components/ui/Button';

// ─── Types ──────────────────────────────────────────────────────────────
interface QuestionAnswerBlockProps {
  questions?: Question[];
  options?: string[];
  onAnswer?: (questionId: string, value: string | string[] | boolean) => void;
  onAllAnswered?: (answers: Record<string, QuestionAnswer>) => void;
  initialAnswers?: Record<string, QuestionAnswer>;
  disabled?: boolean;
  title?: string;
  selectedOption?: string;
  onOptionSelect?: (option: string) => void;
  optional?: boolean;
}

const QuestionAnswerBlock: React.FC<QuestionAnswerBlockProps> = ({
  questions: questionsProp,
  options: optionsProp,
  onAnswer: onAnswerProp,
  onAllAnswered: onAllAnsweredProp,
  initialAnswers = {},
  disabled = false,
  title,
  selectedOption: selectedOptionProp,
  onOptionSelect: onOptionSelectProp,
}) => {
  const isPaginated = questionsProp && questionsProp.length > 0;
  const questions = isPaginated ? questionsProp! : [];
  const legacyOptions = optionsProp || [];

  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, QuestionAnswer>>(initialAnswers);
  const [selectedOptions, setSelectedOptions] = useState<Record<string, string | string[]>>({});
  const [textInputs, setTextInputs] = useState<Record<string, string>>({});
  const [confirmValues, setConfirmValues] = useState<Record<string, boolean>>({});
  const [customValues, setCustomValues] = useState<Record<string, string>>({});
  const [multiCustomValues, setMultiCustomValues] = useState<Record<string, string>>({});
  const [isSummaryModeState, setIsSummaryModeState] = useState(false);
  const isSummaryModeRef = useRef(false);
  const hasRestoredRef = useRef(false);

  const setIsSummaryMode = (value: boolean) => {
    isSummaryModeRef.current = value;
    setIsSummaryModeState(value);
  };

  const isLegacyMode = !isPaginated && legacyOptions.length > 0;
  const legacyAnswered = !!selectedOptionProp;

  useEffect(() => {
    const initialAnswersKeys = Object.keys(initialAnswers);
    const hasInitialAnswers = isPaginated && initialAnswersKeys.length > 0;

    if (hasInitialAnswers) {
      if (hasRestoredRef.current) {
        return;
      }
      hasRestoredRef.current = true;

      const totalQuestions = questions.length;
      const answeredCount = initialAnswersKeys.length;
      if (answeredCount === totalQuestions) {
        setIsSummaryMode(true);
      }

      setAnswers(initialAnswers);
      Object.entries(initialAnswers).forEach(([qId, answer]) => {
        const question = questions.find((q) => q.id === qId);
        if (!question) return;
        if (question.type === 'confirm') {
          setConfirmValues((prev) => ({
            ...prev,
            [qId]: answer.value as boolean,
          }));
        } else if (question.type === 'single' || question.type === 'multi') {
          const value = answer.value;
          if (typeof value === 'string' || Array.isArray(value)) {
            setSelectedOptions((prev) => ({ ...prev, [qId]: value }));
          }
        }
      });
    } else {
      hasRestoredRef.current = false;
    }
  }, [initialAnswers, isPaginated, questions]);

  const currentQuestion = isPaginated ? questions[currentIndex] : null;
  const totalQuestions = questions.length;
  const isLastQuestion = currentIndex === totalQuestions - 1;
  const hasAnsweredAll = isPaginated && Object.keys(answers).length === totalQuestions;
  const isAllAnswered = isPaginated ? isSummaryModeState : legacyAnswered;

  const isCurrentAnswered = useCallback(() => {
    if (!isPaginated || !currentQuestion) return false;
    const q = currentQuestion;
    if (q.type === 'multi') {
      const selected = (selectedOptions[q.id] as string[]) || [];
      return selected.length > 0;
    }
    if (q.type === 'single') {
      const selected = selectedOptions[q.id] as string;
      return !!selected && selected.length > 0;
    }
    if (q.type === 'text') {
      const value = textInputs[q.id] || '';
      return value.trim().length > 0;
    }
    if (q.type === 'confirm') {
      const hasConfirmValue = confirmValues[q.id] !== undefined;
      const hasAnswer = answers[q.id] !== undefined;
      return hasConfirmValue || hasAnswer;
    }
    const answer = answers[q.id];
    if (!answer) return false;
    if (q.type === 'single') return typeof answer.value === 'string' && answer.value.length > 0;
    if (q.type === 'multi') return Array.isArray(answer.value) && answer.value.length > 0;
    if (q.type === 'text')
      return typeof answer.value === 'string' && answer.value.trim().length > 0;
    if (q.type === 'confirm') return typeof answer.value === 'boolean';
    return false;
  }, [isPaginated, currentQuestion, answers, selectedOptions, textInputs, confirmValues]);

  const handleSingleSelect = (option: string) => {
    if (disabled || isAllAnswered || !isPaginated || !currentQuestion) {
      return;
    }
    const answer: QuestionAnswer = {
      questionId: currentQuestion.id,
      value: option,
    };
    const newAnswers = { ...answers, [currentQuestion.id]: answer };
    setAnswers(newAnswers);
    setSelectedOptions((prev) => ({ ...prev, [currentQuestion.id]: option }));
    onAnswerProp?.(currentQuestion.id, option);
  };

  const handleMultiToggle = (option: string) => {
    if (disabled || isAllAnswered || !isPaginated || !currentQuestion) return;
    const currentSelected = (selectedOptions[currentQuestion.id] as string[]) || [];
    const newSelected = currentSelected.includes(option)
      ? currentSelected.filter((o) => o !== option)
      : [...currentSelected, option];
    setSelectedOptions({
      ...selectedOptions,
      [currentQuestion.id]: newSelected,
    });
  };

  const handleTextSubmit = () => {
    if (disabled || isAllAnswered || !isPaginated || !currentQuestion) {
      return;
    }

    const value = textInputs[currentQuestion.id] || '';
    if (value.trim().length === 0) {
      return;
    }

    const answer: QuestionAnswer = {
      questionId: currentQuestion.id,
      value: value.trim(),
    };

    const newAnswers = { ...answers, [currentQuestion.id]: answer };
    setAnswers(newAnswers);
    onAnswerProp?.(currentQuestion.id, value.trim());
    setTimeout(() => {
      if (currentIndex < totalQuestions - 1) {
        setCurrentIndex(currentIndex + 1);
      } else {
        setIsSummaryMode(true);
        onAllAnsweredProp?.(newAnswers);
      }
    }, QUESTION_TRANSITION_DELAY);
  };
  const handleConfirm = (value: boolean) => {
    if (disabled || isAllAnswered || !isPaginated || !currentQuestion) return;
    const answer: QuestionAnswer = { questionId: currentQuestion.id, value };
    const newAnswers = { ...answers, [currentQuestion.id]: answer };
    setAnswers(newAnswers);
    setConfirmValues({ ...confirmValues, [currentQuestion.id]: value });
    onAnswerProp?.(currentQuestion.id, value);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (currentQuestion?.type === 'text') {
        handleTextSubmit();
      }
    }
  };

  const wrapperClassName = 'flex flex-col gap-1.5 pb-3 w-full';

  // --- Legacy rendering ---
  if (isLegacyMode) {
    const legacySelected = selectedOptionProp || null;
    return (
      <div className={wrapperClassName}>
        <TagHeader
          title="QUESTION"
          statusColor={legacyAnswered ? $('--success') : $('--text-secondary')}
        />
        <div className="mt-1">
          {title && <div className="text-[14px] font-medium text-text-primary mb-2">{title}</div>}
          <div className="flex flex-col gap-2">
            {legacyOptions.map((option) => (
              <button
                key={option}
                onClick={() => onOptionSelectProp?.(option)}
                disabled={disabled || legacyAnswered}
                className={cn(
                  'py-1.5 px-3 border-none rounded-none text-[14px] text-left transition-all duration-[0.15s] w-full border-l-[3px]',
                  legacySelected === option
                    ? 'bg-primary text-text-foreground font-semibold opacity-100 border-l-primary'
                    : 'bg-transparent text-text-primary font-normal border-l-text-secondary',
                  legacyAnswered && legacySelected !== option && 'opacity-50',
                  disabled || legacyAnswered ? 'cursor-default' : 'cursor-pointer',
                )}
              >
                {option}
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // --- Paginated rendering ---
  if (!isPaginated || !currentQuestion) {
    return null;
  }

  const getTypeLabel = (type: QuestionType): string => {
    switch (type) {
      case 'single':
        return 'Single choice';
      case 'multi':
        return 'Multiple choice';
      case 'text':
        return 'Text input';
      case 'confirm':
        return 'Confirm';
      default:
        return '';
    }
  };

  const getStatusColor = () => {
    if (isAllAnswered) return $('--success');
    if (isCurrentAnswered()) return $('--success');
    return $('--text-secondary');
  };

  // Render single question type
  const renderSingle = (q: Question) => {
    const isDisabled = disabled || isAllAnswered;
    const selected = (answers[q.id]?.value as string) || '';
    const customValue = customValues[q.id] || '';

    const options = q.options || [];
    const lastOption = options.length > 0 ? options[options.length - 1] : '';
    const hasAiOther =
      lastOption.toLowerCase().includes('khác') || lastOption.toLowerCase().includes('other');

    const updateCustomSelection = (value: string) => {
      setCustomValues((prev) => ({ ...prev, [q.id]: value }));

      if (value.trim()) {
        const fullValue = `Other: ${value.trim()}`;
        setSelectedOptions((prev) => ({
          ...prev,
          [q.id]: fullValue,
        }));
        const answer: QuestionAnswer = { questionId: q.id, value: fullValue };
        setAnswers((prev) => ({ ...prev, [q.id]: answer }));
        onAnswerProp?.(q.id, fullValue);
      } else {
        setSelectedOptions((prev) => {
          const newState = { ...prev };
          delete newState[q.id];
          return newState;
        });
        setAnswers((prev) => {
          const newState = { ...prev };
          delete newState[q.id];
          return newState;
        });
      }
    };

    const renderOtherInput = (isSelected: boolean, placeholder: string, key: string) => {
      return (
        <div
          key={key}
          className={cn(
            'flex items-center px-4 py-2 transition-all duration-[0.15s] cursor-pointer border-l-[3px]',
            isSelected
              ? 'bg-primary/20 border-l-primary'
              : 'bg-text-secondary/5 border-l-text-secondary',
            !isDisabled && (isSelected ? 'hover:bg-primary/30' : 'hover:bg-text-secondary/15'),
          )}
          onClick={() => {
            if (!isDisabled && !isSelected) {
              const savedCustomValue = customValues[q.id] || '';
              const existingAnswer = (answers[q.id]?.value as string) || '';
              const hasKhacValue =
                existingAnswer &&
                existingAnswer.toString().startsWith('Other:') &&
                existingAnswer.toString().length > 'Other: '.length;

              if (savedCustomValue) {
                setCustomValues((prev) => ({
                  ...prev,
                  [q.id]: savedCustomValue,
                }));
                updateCustomSelection(savedCustomValue);
              } else if (hasKhacValue) {
                const existingText = existingAnswer.toString().replace('Other: ', '');
                setCustomValues((prev) => ({ ...prev, [q.id]: existingText }));
                updateCustomSelection(existingText);
              }
            }
          }}
        >
          <input
            type="text"
            value={customValue}
            onChange={(e) => {
              setCustomValues((prev) => ({ ...prev, [q.id]: e.target.value }));
              updateCustomSelection(e.target.value);
            }}
            onFocus={(e) => e.target.select()}
            placeholder={placeholder}
            disabled={isDisabled}
            className={cn(
              'flex-1 p-0 bg-transparent text-text-primary border-none outline-none text-[14px]  min-w-0',
              isSelected ? 'font-semibold' : 'font-normal',
            )}
          />
        </div>
      );
    };

    const renderedItems: React.ReactNode[] = [];

    options.forEach((option, index) => {
      if (index === options.length - 1 && hasAiOther) {
        const isSelected = !!(selected && selected.toString().startsWith('Other:'));
        renderedItems.push(renderOtherInput(isSelected, 'Other (your input)', `other-${q.id}`));
        return;
      }

      const isSelected = selected === option;
      renderedItems.push(
        <button
          key={`${q.id}-${option}`}
          onClick={() => {
            handleSingleSelect(option);
          }}
          disabled={isDisabled}
          className={cn(
            'question-option-btn py-2 px-4 border-none rounded-none text-[14px] text-left transition-[background-color,color,border-color,font-weight] duration-[0.15s] w-full border-l-[3px]',
            isSelected
              ? 'bg-primary/20 text-primary font-semibold opacity-100 border-l-primary'
              : 'bg-text-secondary/5 text-text-primary font-normal border-l-text-secondary',
            !isDisabled && (isSelected ? 'hover:bg-primary/30' : 'hover:bg-text-secondary/15'),
            isDisabled ? 'cursor-default' : 'cursor-pointer',
          )}
        >
          {option}
        </button>,
      );
    });

    if (!hasAiOther) {
      const isSelected = !!(selected && selected.toString().startsWith('Other:'));
      renderedItems.push(renderOtherInput(isSelected, 'Other (your input)', `auto-other-${q.id}`));
    }

    return <div className="flex flex-col gap-2">{renderedItems}</div>;
  };

  // Render multi question type
  const renderMulti = (q: Question) => {
    const isDisabled = disabled || isAllAnswered;
    const selected = (selectedOptions[q.id] as string[]) || [];
    const isAnswered = !!answers[q.id];
    const multiCustomValue = multiCustomValues[q.id] || '';

    const originalOptions = q.options || [];
    const hasOther = originalOptions.some(
      (opt) => opt.toLowerCase().includes('khác') || opt.toLowerCase().includes('other'),
    );

    const options = hasOther ? originalOptions : [...originalOptions, 'Other'];
    const otherOptionText = 'Other';

    const handleMultiCustomChange = (value: string) => {
      setMultiCustomValues((prev) => ({ ...prev, [q.id]: value }));
      if (value.trim()) {
        const fullValue = `Other: ${value.trim()}`;
        const newSelected = selected.filter(
          (opt) => opt !== otherOptionText && !opt.startsWith('Other:'),
        );
        newSelected.push(fullValue);
        setSelectedOptions({ ...selectedOptions, [q.id]: newSelected });
      } else {
        if (!selected.includes(otherOptionText)) {
          const newSelected = [...selected, otherOptionText];
          setSelectedOptions({ ...selectedOptions, [q.id]: newSelected });
        }
      }
    };

    return (
      <div className="flex flex-col gap-1">
        {options.map((option) => {
          const isSelected = selected.includes(option);
          const isOther = option === otherOptionText;
          return (
            <div key={option}>
              <div
                className={cn(
                  'flex items-center gap-2.5 px-1.5 py-2 transition-all duration-[0.15s] border-l-0',
                  isSelected ? 'bg-primary/20' : 'bg-text-secondary/5',
                  !isDisabled &&
                    (isSelected ? 'hover:bg-primary/30' : 'hover:bg-text-secondary/15'),
                  isAnswered && !isSelected && 'opacity-50',
                  isDisabled || isAnswered ? 'cursor-default' : 'cursor-pointer',
                )}
              >
                <input
                  type="checkbox"
                  checked={isSelected}
                  onChange={() => {
                    if (isOther) {
                      if (selected.includes(option)) {
                        const newSelected = selected.filter((opt) => opt !== option);
                        setSelectedOptions({ ...selectedOptions, [q.id]: newSelected });
                        setMultiCustomValues((prev) => ({ ...prev, [q.id]: '' }));
                      } else {
                        const newSelected = [...selected, option];
                        setSelectedOptions({ ...selectedOptions, [q.id]: newSelected });
                      }
                    } else {
                      handleMultiToggle(option);
                    }
                  }}
                  disabled={isDisabled}
                  className="w-4 h-4"
                  style={{
                    accentColor: isSelected ? $('--primary') : $('--secondary-text'),
                    cursor: isDisabled || isAnswered ? 'default' : 'pointer',
                    opacity: isSelected ? 1 : 0.4,
                  }}
                />
                {isOther ? (
                  <>
                    <input
                      type="text"
                      value={multiCustomValue}
                      onChange={(e) => {
                        setMultiCustomValues((prev) => ({
                          ...prev,
                          [q.id]: e.target.value,
                        }));
                        handleMultiCustomChange(e.target.value);
                      }}
                      placeholder="Other (your input)"
                      disabled={isDisabled}
                      className="flex-1 py-0.5 px-2 bg-transparent text-text-primary border-none outline-none text-[14px]  min-w-[60px]"
                      onFocus={(e) => e.target.select()}
                    />
                  </>
                ) : (
                  <span className="text-[14px]">{option}</span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  // Render text question type
  const renderText = (q: Question) => {
    const isDisabled = disabled || isAllAnswered;
    const value = textInputs[q.id] || '';
    return (
      <div className="flex flex-col gap-2">
        <textarea
          value={value}
          onChange={(e) => setTextInputs({ ...textInputs, [q.id]: e.target.value })}
          onKeyDown={handleKeyDown}
          placeholder="Type your answer..."
          disabled={isDisabled}
          className="w-full min-h-[80px] bg-input-background text-text-primary border border-border rounded-[4px] p-2 text-[14px]  resize-y outline-none"
        />
      </div>
    );
  };

  // Render confirm question type
  const renderConfirm = (q: Question) => {
    const isDisabled = disabled || isAllAnswered;
    const selected = confirmValues[q.id];
    const greenColor = $('--success');
    const redColor = $('--error');
    const customValue = customValues[q.id] || '';

    const updateCustomSelection = (value: string) => {
      setCustomValues((prev) => ({ ...prev, [q.id]: value }));
      if (value.trim()) {
        const fullValue = `Opinion: ${value.trim()}`;
        const answer: QuestionAnswer = { questionId: q.id, value: fullValue };
        setAnswers((prev) => ({ ...prev, [q.id]: answer }));
        setConfirmValues((prev) => {
          const newState = { ...prev };
          delete newState[q.id];
          return newState;
        });
        onAnswerProp?.(q.id, fullValue);
      } else {
        setAnswers((prev) => {
          const newState = { ...prev };
          delete newState[q.id];
          return newState;
        });
        setConfirmValues((prev) => {
          const newState = { ...prev };
          delete newState[q.id];
          return newState;
        });
      }
    };

    const renderOptionBar = (value: boolean, label: string, color: string, isSelected: boolean) => {
      const bgColor = isSelected ? `color-mix(in srgb, ${color} 20%, transparent)` : 'transparent';

      return (
        <div
          onClick={() => {
            if (!isDisabled) {
              handleConfirm(value);
            }
          }}
          className={cn(
            'flex items-center px-4 py-2 rounded-none text-[14px] w-full transition-all duration-[0.15s] opacity-100 border-l-[3px]',
            isDisabled ? 'cursor-default' : 'cursor-pointer',
            isSelected ? 'font-semibold' : 'font-normal text-text-primary bg-text-secondary/5',
            !isDisabled && !isSelected && 'hover:bg-text-secondary/15',
            isSelected && value
              ? 'border-l-success'
              : isSelected && !value
                ? 'border-l-error'
                : 'border-l-text-secondary',
          )}
          style={isSelected ? { backgroundColor: bgColor, color } : undefined}
        >
          <span>{label}</span>
        </div>
      );
    };

    return (
      <div className="flex flex-col gap-1 py-1">
        {renderOptionBar(true, 'Yes', greenColor, selected === true)}
        {renderOptionBar(false, 'No', redColor, selected === false)}

        <div
          className={cn(
            'flex items-center px-4 py-2 transition-all duration-[0.15s] cursor-pointer border-l-[3px]',
            customValue.trim()
              ? 'bg-primary/20 border-l-primary'
              : 'bg-text-secondary/5 border-l-text-secondary',
            !isDisabled &&
              (customValue.trim() ? 'hover:bg-primary/30' : 'hover:bg-text-secondary/15'),
          )}
        >
          <input
            type="text"
            value={customValue}
            onChange={(e) => {
              setCustomValues((prev) => ({ ...prev, [q.id]: e.target.value }));
              updateCustomSelection(e.target.value);
            }}
            onFocus={(e) => e.target.select()}
            placeholder="Other opinion..."
            disabled={isDisabled}
            className={cn(
              'flex-1 p-0 bg-transparent text-text-primary border-none outline-none text-[14px]  min-w-0',
              customValue.trim() ? 'font-semibold' : 'font-normal',
            )}
          />
        </div>
      </div>
    );
  };
  const renderQuestionContent = () => {
    if (!currentQuestion) return null;
    switch (currentQuestion.type) {
      case 'single':
        return renderSingle(currentQuestion);
      case 'multi':
        return renderMulti(currentQuestion);
      case 'text':
        return renderText(currentQuestion);
      case 'confirm':
        return renderConfirm(currentQuestion);
      default:
        return null;
    }
  };

  const answeredCount = Object.keys(answers).length;

  const renderNavIcons = () => {
    if (totalQuestions <= 1) return null;
    const iconColor = $('--text-primary');
    const bgColor = `color-mix(in srgb, ${iconColor} 10%, transparent)`;
    return (
      <div className="flex gap-0.5 items-center">
        <button
          onClick={() => setCurrentIndex(Math.max(0, currentIndex - 1))}
          disabled={currentIndex === 0}
          className={cn(
            'border-none p-1 rounded flex items-center justify-center text-text-primary',
            currentIndex === 0
              ? 'bg-transparent cursor-default opacity-30'
              : 'cursor-pointer opacity-80',
          )}
          style={{
            background: currentIndex === 0 ? 'transparent' : bgColor,
          }}
          title="Previous question"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="18"
            height="18"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="m15 18-6-6 6-6" />
          </svg>
        </button>
        <button
          onClick={() => setCurrentIndex(Math.min(totalQuestions - 1, currentIndex + 1))}
          disabled={currentIndex === totalQuestions - 1}
          className={cn(
            'border-none p-1 rounded flex items-center justify-center text-text-primary',
            currentIndex === totalQuestions - 1
              ? 'bg-transparent cursor-default opacity-30'
              : 'cursor-pointer opacity-80',
          )}
          style={{
            background: currentIndex === totalQuestions - 1 ? 'transparent' : bgColor,
          }}
          title="Next question"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="18"
            height="18"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="m9 18 6-6-6-6" />
          </svg>
        </button>
      </div>
    );
  };

  // Render Summary view
  const renderSummary = () => {
    const answerCount = Object.keys(answers).length;
    const statusColor = answerCount === totalQuestions ? $('--success') : $('--secondary-text');

    const formatAnswer = (answer: QuestionAnswer): string => {
      const value = answer.value;
      if (Array.isArray(value)) {
        return value.join(', ');
      }
      if (typeof value === 'boolean') {
        return value ? '✅ Yes' : '❌ No';
      }
      return String(value);
    };

    const getAnswer = (questionId: string): string => {
      const answer = answers[questionId];
      if (!answer) return 'Not answered';
      return formatAnswer(answer);
    };

    return (
      <div className={wrapperClassName}>
        <TagHeader
          title={
            <div className="flex items-center gap-2 text-[13px] text-text-primary">
              <span className="font-semibold opacity-80">QUESTION</span>
              <span className="text-[11px] opacity-50 font-normal ml-1">
                ✅ Answered {answerCount}/{totalQuestions}
              </span>
            </div>
          }
          statusColor={statusColor}
        />
        <div className="mt-2">
          {title && (
            <div className="text-[14px] font-medium text-text-primary mb-3 py-1">{title}</div>
          )}

          <div className="flex flex-col gap-2.5">
            {questions.map((q, index) => {
              const answer = getAnswer(q.id);
              const isAnswered = !!answers[q.id];

              return (
                <div key={q.id} className="flex flex-col gap-0.5 px-3 py-1.5 rounded-none">
                  <div className="flex items-center gap-1.5 text-[14px] font-medium text-text-primary">
                    <span className="text-[14px] font-semibold text-text-secondary opacity-60 min-w-[28px]">
                      {index + 1}.
                    </span>
                    <span className="-ml-0.5">{q.label}</span>
                  </div>
                  <div
                    className={cn(
                      'text-[14px] pl-[30px]',
                      isAnswered
                        ? 'text-text-primary font-medium opacity-100'
                        : 'text-text-secondary font-normal opacity-50',
                    )}
                  >
                    {isAnswered ? (
                      <span className="inline-block px-2.5 py-0.5 bg-primary/15 rounded text-[13px]">
                        {answer}
                      </span>
                    ) : (
                      <span className="italic">Not answered</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  };

  const willRenderSummary = isSummaryModeState && isPaginated;
  if (willRenderSummary) {
    return renderSummary();
  }

  return (
    <div className={wrapperClassName}>
      <TagHeader
        title={
          <div className="flex items-center gap-2 text-[13px] text-text-primary">
            <span className="font-semibold opacity-80">QUESTION</span>
            <span className="text-[11px] opacity-50 font-normal ml-1">
              {`${answeredCount} / ${totalQuestions} answered`}
            </span>
          </div>
        }
        statusColor={getStatusColor()}
        headerActions={hasAnsweredAll ? renderNavIcons() : undefined}
      />
      <div className=" mt-2">
        <div className="text-[15px] font-medium text-text-primary py-1 pb-2">
          {currentQuestion?.label}
          {currentQuestion?.type && (
            <span className="text-[11px] font-normal text-text-secondary ml-2 opacity-60 uppercase tracking-[0.3px]">
              ({getTypeLabel(currentQuestion.type)})
            </span>
          )}
        </div>

        <div className="py-0.5">{renderQuestionContent()}</div>

        {!isSummaryModeState && (
          <div className="flex justify-end gap-2 mt-2">
            {totalQuestions > 1 && (
              <Button
                className="rounded-sm px-5 py-2 text-sm text-primary hover:bg-text-secondary/10 hover:text-text-secondary active:bg-primary/20"
                onClick={() => setCurrentIndex(Math.max(0, currentIndex - 1))}
                disabled={currentIndex === 0}
              >
                Previous
              </Button>
            )}
            <Button
              className="rounded-sm px-5 py-2 text-sm bg-text-secondary/10 text-text-secondary hover:bg-primary/10 hover:text-primary active:bg-primary/20"
              onClick={() => {
                let allAnswers = answers;
                if (currentQuestion?.type === 'multi') {
                  const selected = (selectedOptions[currentQuestion.id] as string[]) || [];
                  if (selected.length === 0 && !isLastQuestion) return;
                  if (selected.length > 0) {
                    const answer: QuestionAnswer = {
                      questionId: currentQuestion.id,
                      value: selected,
                    };
                    allAnswers = {
                      ...answers,
                      [currentQuestion.id]: answer,
                    };
                    setAnswers(allAnswers);
                    onAnswerProp?.(currentQuestion.id, selected);
                  }
                }

                if (currentQuestion?.type === 'text') {
                  const value = textInputs[currentQuestion.id] || '';
                  if (value.trim().length === 0 && !isLastQuestion) return;
                  if (value.trim().length > 0) {
                    const answer: QuestionAnswer = {
                      questionId: currentQuestion.id,
                      value: value.trim(),
                    };
                    allAnswers = {
                      ...answers,
                      [currentQuestion.id]: answer,
                    };
                    setAnswers(allAnswers);
                    onAnswerProp?.(currentQuestion.id, value.trim());
                  }
                }

                if (isCurrentAnswered()) {
                  if (currentIndex < totalQuestions - 1) {
                    setCurrentIndex(currentIndex + 1);
                  } else {
                    setIsSummaryMode(true);
                    onAllAnsweredProp?.(allAnswers);
                  }
                } else if (isLastQuestion) {
                  // Skip the final unanswered question and finish
                  setIsSummaryMode(true);
                  onAllAnsweredProp?.(allAnswers);
                }
              }}
              disabled={isLastQuestion ? false : !isCurrentAnswered()}
            >
              {isLastQuestion ? 'Finish' : 'Next'}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

// ─── Types ──────────────────────────────────────────────────────────────
interface QuestionRendererProps {
  questions?: Question[];
  options?: string[];
  title?: string;
  optional?: boolean;
  selectedOption?: string;
  questionAnswers?: Record<string, QuestionAnswer>;
  disabled?: boolean;
  onAnswer?: (questionId: string, value: string | string[] | boolean) => void;
  onAllAnswered?: (answers: Record<string, QuestionAnswer>) => void;
  onOptionSelect?: (option: string) => void;
}

/**
 * Renderer cho block câu hỏi/tùy chọn
 * Xử lý cả định dạng tùy chọn đơn và nhiều câu hỏi
 */
export const QuestionRenderer: React.FC<QuestionRendererProps> = ({
  questions,
  options,
  title,
  optional,
  selectedOption,
  questionAnswers,
  disabled,
  onAnswer,
  onAllAnswered,
  onOptionSelect,
}) => {
  const hasQuestions = questions && questions.length > 0;

  return (
    <QuestionAnswerBlock
      questions={hasQuestions ? questions : undefined}
      options={!hasQuestions ? options : undefined}
      title={title}
      optional={optional}
      selectedOption={!hasQuestions ? selectedOption : undefined}
      initialAnswers={hasQuestions ? questionAnswers : undefined}
      disabled={disabled}
      onAnswer={(questionId, value) => {
        if (!hasQuestions) return;
        if (onAnswer) {
          onAnswer(questionId, value);
        }
      }}
      onAllAnswered={(answers) => {
        if (!hasQuestions) return;
        if (onAllAnswered) {
          onAllAnswered(answers);
        }
      }}
      onOptionSelect={(option: string) => {
        if (hasQuestions) return;
        if (onOptionSelect) {
          onOptionSelect(option);
        }
      }}
    />
  );
};
