/**
 * ------------------------------------------------------------------
 * useChatLLM
 * ------------------------------------------------------------------
 * Main hook managing the entire chat LLM flow.
 * Handles send message, streaming response, and tool execution.
 *
 * Main features:
 * - sendMessage          : Send message and handle streaming response
 * - stopGeneration       : Stop ongoing generation
 * - Tool auto-execution  : Auto-execute tools after AI response
 * ------------------------------------------------------------------
 */

// ─── Imports ────────────────────────────────────────────────────────────
// ── React ──
import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
// ── Types ──
import { Message, QuestionAnswer } from '../../types/message';
import { ToolAction, parseAIResponse } from '../../services/responseParser';
import type { ChatSession } from '../../types/chat';

import { extensionService } from '@renderer/components/Widgets/Zen/services/ExtensionService';
import { getModuleService } from '../../services/moduleRegistry';
import type { WorkflowAgentId } from '../../types/workflow-agents';
import type { ToolFormatId } from '../../services/tool-format-parsers/types';
import { DEFAULT_TOOL_FORMAT } from '../../services/tool-format-parsers';
import type { AgentFeature } from '@renderer/components/Widgets/Zen/context/FeatureContext';
import {
  calculateTokens,
  deleteConversation,
  saveConversation,
  logChatToWorkspace,
} from '../../services/conversationService';
import { PromptBuilder } from '../../services/promptBuilder';
import { StreamingService } from '../../services/streamingService';
import { cleanClaudeSandboxTools } from '../../services/claudeSandboxToolCleaner';

import { hasDeepseekDSML, processDeepseekContent } from '../../services/DSMLConvertOtherToolFormat';
import { TOOL_ACTION_TYPES } from '../../constants/tag-registry';

import { useStreamingState } from './useStreamingState';
import { useConversationRefs } from './useConversationRefs';
import { useMessageHandlers } from './useMessageHandlers';
import { useSettings } from '@renderer/components/Widgets/Zen/context/SettingsContext';
import { useProject } from '@renderer/components/Widgets/Zen/context/ProjectContext';
import { useFileUpload } from '../workspace/useFileUpload';

// ── Utils ──
const notifyDesktop = (title: string, body: string): void => {
  try {
    window.api?.invoke('notification:show', { title, body })?.catch(() => {});
  } catch {
    // ignore
  }
};

// ── Services ──
const getTrafficSummary = getModuleService('emulate', 'getTrafficSummary');
const getCurrentFilter = getModuleService('emulate', 'getCurrentFilter');
const getFilterText = getModuleService('emulate', 'getFilterText');

// ── Prompts ──
const buildTrafficContext = getModuleService('emulate', 'buildTrafficContext');
const buildEmptyTrafficContext = getModuleService('emulate', 'buildEmptyTrafficContext');
const buildFilterContext = getModuleService('emulate', 'buildFilterContext');
const buildEmptyFilterContext = getModuleService('emulate', 'buildEmptyFilterContext');

// ─── Types ──────────────────────────────────────────────────────────────
interface ConversationOverrides {
  useSkillEnabled?: boolean;
  memoryEnabled?: boolean;
  toolFormat?: ToolFormatId;
  workflowAgentId?: WorkflowAgentId | null;
}

interface UseChatLLMProps {
  apiUrl: string;
  selectedTab: ChatSession | null;
  feature?: string | null;
  conversationOverrides?: ConversationOverrides;
  providerBlockedRanges?: Array<{ startTime: number; endTime: number }> | null;
  workflowAgentId?: WorkflowAgentId | null;
  onConversationIdChange?: (id: string) => void;
  onToolRequest?: (
    actions: ToolAction[],
    assistantMessage: Message,
    isAutoTrigger?: boolean,
    actionType?: (typeof TOOL_ACTION_TYPES)[keyof typeof TOOL_ACTION_TYPES],
  ) => void;
  /**
   * Callback fired when entire response turn is complete (markdown-only done,
   * or tool execution chain stopped).
   */
  onTurnComplete?: () => void;
  onMalformedTool?: (
    actionId: string,
    toolName: string,
    errorMessage: string,
    errorCode: string,
  ) => void;
}
export const parseQuestionAnswerTag = (content: string): Record<string, QuestionAnswer> | null => {
  const regex = /<question-answer>([\s\S]*?)<\/question-answer>/i;
  const match = regex.exec(content);
  if (!match) return null;

  const innerContent = match[1].trim();
  const answers: Record<string, QuestionAnswer> = {};

  // Parse each line: "N. answer" (without questionId)
  const lines = innerContent.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const trimmed = lines[i].trim();

    // Match pattern: "N. answer" or "N. " (empty answer)
    const lineMatch = /^(\d+)\.\s*(.*)$/i.exec(trimmed);
    if (!lineMatch) continue;

    const lineNumber = parseInt(lineMatch[1], 10);
    const answerText = lineMatch[2].trim();

    // Use line number as questionId (matching question.id format: "1", "2", "3", etc.)
    const questionId = String(lineNumber);

    // Skip if empty answer (no value provided)
    if (!answerText) {
      continue;
    }

    // Keep answer as string - QuestionBlock will handle type conversion based on question type
    let parsedValue: string | string[] | boolean = answerText;

    // Only convert explicit "true"/"false" literals to boolean
    if (answerText.toLowerCase() === 'true') {
      parsedValue = true;
    } else if (answerText.toLowerCase() === 'false') {
      parsedValue = false;
    }

    answers[questionId] = {
      questionId,
      value: parsedValue,
    };
  }

  return Object.keys(answers).length > 0 ? answers : null;
};

export const useChatLLM = ({
  apiUrl,
  selectedTab,
  feature,
  conversationOverrides,
  providerBlockedRanges,
  workflowAgentId,
  onConversationIdChange,
  onToolRequest,
  onTurnComplete,
  onMalformedTool,
}: UseChatLLMProps) => {
  // Ref to hold per-conversation overrides (from Home panel or restored from metadata).
  const conversationOverridesRef = useRef<ConversationOverrides | undefined>(conversationOverrides);
  const prevSelectedTabIdRef = useRef<string | number | undefined>(selectedTab?.sessionId);
  const onTurnCompleteRef = useRef(onTurnComplete);
  const dsmlUnconvertedRef = useRef(false);
  useEffect(() => {
    const currentTabId = selectedTab?.sessionId;
    const tabChanged = currentTabId !== prevSelectedTabIdRef.current;
    prevSelectedTabIdRef.current = currentTabId;

    if (tabChanged) {
      conversationOverridesRef.current = conversationOverrides;
    } else if (conversationOverrides !== undefined) {
      conversationOverridesRef.current = conversationOverrides;
    }
  }, [conversationOverrides, selectedTab?.sessionId]);

  useEffect(() => {
    onTurnCompleteRef.current = onTurnComplete;
  }, [onTurnComplete]);

  const MAX_NO_TAG_FOLLOWUP = 5;
  const noTagFollowUpCountRef = useRef(0);
  const MAX_MOCK_REQUESTS = 2;
  const mockRequestCountRef = useRef(0);

  const {
    streamingState,
    dispatchStreaming,
    isProcessingRef,
    setIsProcessingSync,
    setIsContinuingSync,
  } = useStreamingState();

  const {
    messagesRef,
    currentConversationIdRef,
    backendConversationIdRef,
    lastUsedModelRef,
    lastUsedAccountRef,
    abortControllerRef,
    qwenParentIdRef,
    userRequestCountRef,
    renderCountRef,
  } = useConversationRefs();

  renderCountRef.current++;

  // NOTE: useSkillEnabled & memoryEnabled are not yet in SettingsContext for Phantoma.
  // We rely solely on conversationOverridesRef for now. Default to false if no override provided.
  const { aiLanguage, promptLengthMode, systemPromptMode } = useSettings();
  const { workspace, treeView } = useProject();
  const { uploadFiles } = useFileUpload(apiUrl);

  const [messages, setMessages] = useState<Message[]>([]);
  const [currentConversationId, setCurrentConversationId] = useState<string>('');
  const [conversationToolOverrides, setConversationToolOverrides] = useState<
    Record<string, 'auto'>
  >({});

  useEffect(() => {
    messagesRef.current = messages;
  }, [messages]);

  useEffect(() => {
    if (
      !currentConversationIdRef.current ||
      currentConversationIdRef.current === currentConversationId
    ) {
      currentConversationIdRef.current = currentConversationId;
    }
    onConversationIdChange?.(currentConversationId);
  }, [currentConversationId, onConversationIdChange]);

  useMessageHandlers({
    selectedTab,
    setMessages,
    currentConversationIdRef,
    backendConversationIdRef,
  });

  const resetSession = useCallback(() => {
    // Abort any ongoing request
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }

    currentConversationIdRef.current = '';
    backendConversationIdRef.current = '';
    messagesRef.current = [];
    lastUsedModelRef.current = null;
    lastUsedAccountRef.current = null;
    qwenParentIdRef.current = undefined;
    userRequestCountRef.current = 0;
    setCurrentConversationId('');
    setMessages([]);
    setIsProcessingSync(false);
    setIsContinuingSync(false);
    dispatchStreaming({ type: 'STOP_ALL' });
    setConversationToolOverrides({});

    // Clear sessionStorage
    try {
      const keys = Object.keys(sessionStorage);
      keys.forEach((key) => {
        if (key.startsWith('zen-backend-conv:') || key.startsWith('zen-revert-parent:')) {
          sessionStorage.removeItem(key);
        }
      });
    } catch (err) {
      console.warn('[useChatLLM] Failed to clear sessionStorage:', err);
    }
  }, [setIsProcessingSync, setIsContinuingSync, dispatchStreaming]);

  const stopGeneration = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }

    if (isProcessingRef.current && messagesRef.current.length <= 2) {
      const chatId = currentConversationIdRef.current;
      if (chatId) {
        deleteConversation(chatId);
        setCurrentConversationId('');
        setMessages([]);
        userRequestCountRef.current = 0;
      }
    }

    dispatchStreaming({ type: 'STOP_ALL' });

    extensionService.postMessage({
      command: 'stopCommand',
      actionId: 'all',
      kill: true,
    });
  }, [dispatchStreaming]);

  const sendMessage = useCallback(
    async (
      content: string,
      files?: any[],
      model?: any,
      account?: any,
      skipFirstRequestLogic?: boolean,
      actionIds?: string[],
      uiHidden?: boolean,
      parentMessageId?: string,
      extraOptions?: {
        user_action?: string;
        edit_message_id?: string;
        parent_message_id?: string;
      },
    ) => {
      if (isProcessingRef.current && !skipFirstRequestLogic) {
        return;
      }

      const sessionId = selectedTab?.sessionId || -1;
      const folderPath = selectedTab?.folderPath || null;

      // Filter cancelled messages
      const currentMessages = messagesRef.current;
      let filteredMessages = currentMessages.filter((m) => !m.isCancelled);

      // For Qwen edit/regenerate: trim UI messages so only history up to (and including)
      // the edited user message is kept. Qwen handles server-side deletion of children.
      if (extraOptions?.user_action === 'edit' && extraOptions.edit_message_id) {
        const editFid = extraOptions.edit_message_id;
        const editIdx = filteredMessages.findIndex(
          (m) => m.role === 'user' && m.providerFid === editFid,
        );

        if (editIdx !== -1) {
          filteredMessages = filteredMessages.slice(0, editIdx + 1);
          messagesRef.current = filteredMessages;
          setMessages(filteredMessages);
        }
      }

      // Check if last message pair is complete; clean up incomplete pairs before sending
      const isEditFlow = extraOptions?.user_action === 'edit';
      if (!skipFirstRequestLogic && !isEditFlow && filteredMessages.length > 0) {
        const lastMsg = filteredMessages[filteredMessages.length - 1];

        if (lastMsg.role === 'user') {
          // Last message is a user request without assistant response → remove it
          filteredMessages = filteredMessages.slice(0, -1);
          messagesRef.current = filteredMessages;
          setMessages(filteredMessages);
        } else if (lastMsg.role === 'assistant' && lastMsg.isError) {
          // Last message is an error assistant → remove both the error + preceding user request
          filteredMessages = filteredMessages.slice(0, -2);
          messagesRef.current = filteredMessages;
          setMessages(filteredMessages);
        }
        // If last message is assistant (success) → pair is complete, proceed normally
      }

      let effectiveChatUuid = currentConversationIdRef.current;
      const isNewSession = !effectiveChatUuid;

      // Guard: tool results must never create new session
      if (skipFirstRequestLogic && isNewSession) {
        return;
      }

      if (isNewSession) {
        effectiveChatUuid = crypto.randomUUID?.() || Date.now().toString();
        currentConversationIdRef.current = effectiveChatUuid;
        setCurrentConversationId(effectiveChatUuid);
        backendConversationIdRef.current = '';

        if (model) lastUsedModelRef.current = model;
        if (account) lastUsedAccountRef.current = account;
        setConversationToolOverrides({});
      }

      const isReq1 = filteredMessages.length === 0 && !skipFirstRequestLogic;

      // Increment user request counter
      if (!skipFirstRequestLogic) {
        userRequestCountRef.current += 1;
      }

      // Build traffic context for emulate feature
      let trafficContext: string | undefined;
      if (feature === 'emulate') {
        try {
          const summary = getTrafficSummary();
          const isEmpty =
            summary.hosts.length === 0 &&
            summary.methods.length === 0 &&
            summary.statuses.length === 0 &&
            summary.types.length === 0;

          trafficContext = isEmpty ? buildEmptyTrafficContext() : buildTrafficContext(summary);
        } catch (err) {
          trafficContext = undefined;
        }
      }

      // Build filter context for emulate feature
      let filterContext: string | undefined;
      if (feature === 'emulate') {
        try {
          const filter = getCurrentFilter();
          if (filter) {
            filterContext = buildFilterContext(getFilterText());
          } else {
            filterContext = buildEmptyFilterContext();
          }
        } catch (err) {
          filterContext = undefined;
        }
      }

      // Calculate effective settings with per-conversation overrides taking priority.
      // Since Phantoma's SettingsContext does not yet expose global toggles for Skill/Memory,
      // we default to false if no explicit override is provided in the current conversation.
      const effectiveUseSkill = conversationOverridesRef.current?.useSkillEnabled ?? false;
      const effectiveMemory = conversationOverridesRef.current?.memoryEnabled ?? false;
      const effectiveToolFormat =
        conversationOverridesRef.current?.toolFormat ?? DEFAULT_TOOL_FORMAT;

      // Determine model/account before building prompt to resolve providerId correctly
      const oldModel = lastUsedModelRef.current;
      const oldAccount = lastUsedAccountRef.current;
      let finalModel = model || oldModel;
      let finalAccount = account || oldAccount;

      if (!finalModel && !oldModel) {
        const lastMetadataMsg = [...filteredMessages]
          .reverse()
          .find((m) => m.role === 'assistant' && m.providerId && m.modelId);
        if (lastMetadataMsg) {
          finalModel = {
            id: lastMetadataMsg.modelId!,
            providerId: lastMetadataMsg.providerId!,
          };
        }
      }

      if (!finalAccount && !oldAccount) {
        const lastMetadataMsg = [...filteredMessages]
          .reverse()
          .find((m) => m.role === 'assistant' && m.accountId);
        if (lastMetadataMsg?.accountId) {
          finalAccount = { id: lastMetadataMsg.accountId };
        }
      }

      if (finalModel) lastUsedModelRef.current = finalModel;
      if (finalAccount) lastUsedAccountRef.current = finalAccount;

      const modelSwitched =
        !skipFirstRequestLogic &&
        oldModel &&
        finalModel &&
        (oldModel.id !== finalModel.id || oldModel.providerId !== finalModel.providerId);
      const accountSwitched =
        !skipFirstRequestLogic && oldAccount && finalAccount && oldAccount.id !== finalAccount.id;

      if (modelSwitched || accountSwitched) {
        console.warn(`[Zen] Model/account switched — resetting backend conversationId`);
        backendConversationIdRef.current = '';
        qwenParentIdRef.current = undefined;
        try {
          sessionStorage.removeItem(`zen-backend-conv:${effectiveChatUuid}`);
        } catch {
          console.warn('[useChatLLM] Failed to remove backend conversation from sessionStorage');
        }
      }

      // Block excessive mock requests to avoid an infinite loop when mock-response.txt has content
      if (StreamingService.isMockActive()) {
        if (isNewSession) mockRequestCountRef.current = 0;
        mockRequestCountRef.current += 1;
        if (mockRequestCountRef.current > MAX_MOCK_REQUESTS) {
          console.warn(
            `[DEBUG][Mock] Blocked request #${mockRequestCountRef.current} (limit ${MAX_MOCK_REQUESTS}) to avoid loop while mock-response.txt has value`,
          );
          mockRequestCountRef.current = 0;
          onTurnCompleteRef.current?.();
          return;
        }
      }

      // Build prompt using PromptBuilder with per-conversation overrides applied
      const promptProviderId = finalModel?.providerId ?? lastUsedModelRef.current?.providerId;

      console.warn(
        `[DEBUG][BuildPrompt] isReq1=${isReq1} skipFirstRequestLogic=${!!skipFirstRequestLogic} isNewSession=${isNewSession} filteredMessagesLen=${filteredMessages.length} uiHidden=${!!uiHidden} contentLen=${content.length}`,
      );
      const builtPayload = await PromptBuilder.buildPrompt({
        content,
        isReq1,
        skipFirstRequestLogic: skipFirstRequestLogic || false,
        aiLanguage,
        treeView,
        workspace,
        files,
        userRequestCount: userRequestCountRef.current,
        feature: feature as AgentFeature,
        trafficContext,
        filterContext,
        useSkillEnabled: effectiveUseSkill,
        memoryEnabled: effectiveMemory,
        toolFormat: effectiveToolFormat,
        providerId: promptProviderId,
        promptLengthMode,
        systemPromptMode,
        workflowAgentId,
      });

      const promptPayload = builtPayload;

      const userMessage: Message = {
        id: `msg-${Date.now()}-${skipFirstRequestLogic ? 'tool' : 'user'}`,
        role: 'user',
        content: promptPayload,
        timestamp: Date.now(),
        token_usage: calculateTokens(promptPayload),
        actionIds: actionIds,
        uiHidden: uiHidden,
        conversationId: backendConversationIdRef.current || undefined,
        uploadedFiles: files
          ?.filter((f: any) => f.type?.startsWith('image/') || f.file_id)
          .map((f: any) => ({
            id: f.id,
            name: f.name,
            size: f.size,
            type: f.type,
            content: f.content,
            file_id: f.file_id,
          })),
        attachedItems: files
          ?.filter(
            (f: any) =>
              f.type === 'file' ||
              f.type === 'folder' ||
              f.type === 'external' ||
              f.type === 'text-snippet',
          )
          .map((f: any) => ({
            id: f.id,
            path: f.path,
            type: f.type,
            content: f.content,
            lineCount: f.lineCount,
          })),
      };

      const updatedMessages = [...filteredMessages, userMessage];

      // Parse question answers
      const parsedAnswers = parseQuestionAnswerTag(content);
      if (parsedAnswers) {
        for (let i = updatedMessages.length - 2; i >= 0; i--) {
          const msg = updatedMessages[i];
          if (msg.role === 'assistant') {
            const effectiveToolFormat =
              conversationOverridesRef.current?.toolFormat ?? DEFAULT_TOOL_FORMAT;
            const parsed = parseAIResponse(msg.content, effectiveToolFormat, feature);
            if (
              parsed.question &&
              parsed.question.type === 'question' &&
              'questions' in parsed.question &&
              parsed.question.questions &&
              parsed.question.questions.length > 0
            ) {
              updatedMessages[i] = {
                ...msg,
                questionAnswers: parsedAnswers,
              };
              break;
            }
          }
        }
      }

      setMessages(updatedMessages);
      setIsProcessingSync(true);

      saveConversation(
        sessionId,
        folderPath,
        updatedMessages,
        effectiveChatUuid,
        false,
        backendConversationIdRef.current,
        undefined,
        undefined,
        undefined,
        conversationOverridesRef.current,
      );

      try {
        const ref_file_ids: string[] = [];
        const localFiles = files
          ? files.filter(
              (f: any) =>
                !f.id?.startsWith('attached-') &&
                !f.id?.startsWith('rule-') &&
                !f.id?.startsWith('terminal-') &&
                !f.id?.startsWith('snippet-') &&
                !f.id?.startsWith('external-'),
            )
          : [];

        if (localFiles.length > 0) {
          if (!finalAccount?.id) {
            throw new Error('No active account selected for file upload');
          }
          const uploadedIds = await uploadFiles(localFiles, finalAccount.id);
          ref_file_ids.push(...uploadedIds);
        }

        // [DEBUG] Add file_id from screenshot if exists (Recon feature)
        const getLastScreenshotFileId = getModuleService('recon', 'getLastScreenshotFileId');
        const clearLastScreenshotFileId = getModuleService('recon', 'clearLastScreenshotFileId');
        if (getLastScreenshotFileId && clearLastScreenshotFileId) {
          const screenshotFileId = getLastScreenshotFileId();
          if (screenshotFileId && !ref_file_ids.includes(screenshotFileId)) {
            ref_file_ids.push(screenshotFileId);
            clearLastScreenshotFileId();
          }
        }

        let payloadMessages = updatedMessages
          .filter((m) => !m.isError)
          .map((m) => ({
            role: m.role,
            content: m.content,
          }));

        const effectiveParentMessageId = qwenParentIdRef.current ?? parentMessageId;

        const convIdToSend =
          backendConversationIdRef.current ||
          (effectiveChatUuid
            ? sessionStorage.getItem(`zen-backend-conv:${effectiveChatUuid}`) || undefined
            : undefined);

        const abortController = new AbortController();
        abortControllerRef.current = abortController;
        dispatchStreaming({ type: 'SET_STREAMING', payload: true });

        updatedMessages[updatedMessages.length - 1].rawRequest = userMessage.content;
        setMessages((prev) =>
          prev.map((m) =>
            m.id === userMessage.id ? { ...m, rawRequest: userMessage.content } : m,
          ),
        );

        // For Qwen regenerate support: save the fid and parentId used for this message
        // so that handleRegenerateRequest can pass them back as edit_message_id / parent_message_id.
        const isQwenProvider = (finalModel?.providerId ?? '').toLowerCase() === 'qwen';
        // Pre-generate fid for Qwen messages (both normal chat and edit).
        // This fid is passed to the provider so the server stores the exact same UUID,
        // allowing us to reference it later for regenerate/edit.
        const qwenMessageFid =
          isQwenProvider && !skipFirstRequestLogic ? crypto.randomUUID() : undefined;

        if (qwenMessageFid) {
          userMessage.providerFid = qwenMessageFid;
          userMessage.providerParentId = effectiveParentMessageId ?? undefined;
          setMessages((prev) =>
            prev.map((m) =>
              m.id === userMessage.id
                ? {
                    ...m,
                    providerFid: qwenMessageFid,
                    providerParentId: effectiveParentMessageId ?? undefined,
                  }
                : m,
            ),
          );
        }

        // Create placeholder assistant message
        const assistantMessageId = `msg-${Date.now()}-assistant`;
        const placeholderAssistant: Message = {
          id: assistantMessageId,
          role: 'assistant',
          content: '',
          timestamp: Date.now(),
        };

        setMessages((prev) => [...prev, placeholderAssistant]);

        const parsedContentRef = { value: '' };

        // Stream the response using StreamingService
        const { message: assistantMessage, backendConversationId } =
          await StreamingService.streamChat(
            {
              apiUrl,
              model: finalModel,
              account: finalAccount,
              messages: payloadMessages,
              conversationId: convIdToSend,
              parentMessageId: effectiveParentMessageId,
              refFileIds: ref_file_ids,
              abortSignal: abortController.signal,
              // Pass the pre-generated fid so the provider stores the exact UUID we saved.
              ...(qwenMessageFid ? { messageFid: qwenMessageFid } : {}),
              ...(extraOptions?.user_action ? { userAction: extraOptions.user_action } : {}),
              ...(extraOptions?.edit_message_id
                ? { editMessageId: extraOptions.edit_message_id }
                : {}),
            },
            {
              onMetadata: (meta) => {
                if (meta.parent_id) {
                  qwenParentIdRef.current = meta.parent_id;
                }

                if (meta.providerId || meta.modelId) {
                  const serverModelId = meta.modelId || lastUsedModelRef.current?.id;
                  const serverProviderId = meta.providerId || lastUsedModelRef.current?.providerId;
                  const sentModelId = finalModel?.id;
                  const sentProviderId = finalModel?.providerId;

                  if (
                    !lastUsedModelRef.current ||
                    (serverModelId === sentModelId && serverProviderId === sentProviderId)
                  ) {
                    lastUsedModelRef.current = {
                      id: serverModelId,
                      providerId: serverProviderId,
                    };
                  }
                }

                if (meta.accountId) {
                  lastUsedAccountRef.current = { id: meta.accountId };
                }
              },
              onContinuing: (isContinuing) => {
                setIsContinuingSync(isContinuing);
              },
              // PERF: Khong goi setMessages trong streaming nua
              // Thay vao do chi tich luy vao ref, ProcessingIndicator tu hien thi timer
              // Tranh 130+ lan re-render toan bo UI moi khi stream
              onRawContent: (_content) => {
                // PERF: Khong goi setMessages trong streaming nua
                // Thay vao do chi tich luy vao ref, ProcessingIndicator tu hien thi timer
                // Tranh 130+ lan re-render toan bo UI moi khi stream
              },
              onContent: (rawContent) => {
                let content = rawContent;
                const streamToolFormat =
                  conversationOverridesRef.current?.toolFormat ?? DEFAULT_TOOL_FORMAT;

                if ((finalModel?.providerId ?? '').toLowerCase() === 'claude') {
                  content = cleanClaudeSandboxTools(content);
                } else if ((finalModel?.providerId ?? '').toLowerCase() === 'deepseek') {
                  const processed = processDeepseekContent(rawContent, streamToolFormat);
                  dsmlUnconvertedRef.current = hasDeepseekDSML(processed.content);
                  if (dsmlUnconvertedRef.current) {
                    console.warn(
                      `[DEBUG][DSML] Unconverted DSML remains (converted=${processed.convertedToolCount}, format=${streamToolFormat}) → will trigger follow-up request`,
                    );
                  }
                  if (processed.convertedToolCount > 0) {
                    content = processed.content;
                  }
                }
                parsedContentRef.value = content;
                // Update UI with parsed content (called ONCE at the end with full content)
                setMessages((prev) => {
                  const targetIndex = prev.findIndex((m) => m.id === assistantMessageId);
                  if (targetIndex === -1) {
                    console.warn('[useChatLLM] setMessages: assistantMessageId not found', {
                      assistantMessageId,
                      messageIds: prev.map((m) => m.id),
                    });
                    return prev;
                  }

                  const currentMessage = prev[targetIndex];

                  // Replace content and clear thinking
                  const updatedMessage = {
                    ...currentMessage,
                    content: content,
                    thinking: undefined,
                  };
                  const newArray = prev.slice();
                  newArray[targetIndex] = updatedMessage;
                  return newArray;
                });
              },
            },
          );

        assistantMessage.id = assistantMessageId;

        if (parsedContentRef.value) {
          assistantMessage.content = parsedContentRef.value;
          assistantMessage.rawResponse = assistantMessage.thinking
            ? `${assistantMessage.thinking}\n\n${parsedContentRef.value}`
            : parsedContentRef.value;
        }

        if (backendConversationId) {
          backendConversationIdRef.current = backendConversationId;
          try {
            sessionStorage.setItem(`zen-backend-conv:${effectiveChatUuid}`, backendConversationId);
          } catch {
            console.warn('[useChatLLM] Failed to save backend conversation to sessionStorage');
          }
        }

        try {
          const userMsgToLog = updatedMessages[updatedMessages.length - 1];
          const finalConversationId = backendConversationId || backendConversationIdRef.current;

          userMsgToLog.providerId = assistantMessage.providerId || finalModel?.providerId;
          userMsgToLog.modelId = assistantMessage.modelId || finalModel?.id;
          userMsgToLog.accountId = assistantMessage.accountId || finalAccount?.id;
          if (assistantMessage.websiteUrl) userMsgToLog.websiteUrl = assistantMessage.websiteUrl;
          if (assistantMessage.email) userMsgToLog.email = assistantMessage.email;

          assistantMessage.providerId = userMsgToLog.providerId;
          assistantMessage.modelId = userMsgToLog.modelId;
          assistantMessage.accountId = userMsgToLog.accountId;
          if (userMsgToLog.websiteUrl) assistantMessage.websiteUrl = userMsgToLog.websiteUrl;
          if (userMsgToLog.email) assistantMessage.email = userMsgToLog.email;

          logChatToWorkspace(effectiveChatUuid, {
            ...userMsgToLog,
            conversationId: finalConversationId,
          });

          logChatToWorkspace(effectiveChatUuid, {
            ...assistantMessage,
            conversationId: finalConversationId,
          });
        } catch (logErr) {
          console.warn('[useChatLLM] Failed to log chat to workspace:', logErr);
        }

        setMessages([...updatedMessages, assistantMessage]);
        setIsProcessingSync(false);
        dispatchStreaming({ type: 'RESET_STREAMING' });
        abortControllerRef.current = null;

        // Parse response to extract tool sequence with error handling
        let parsed: any = null;
        let hasParsingError = false;

        try {
          // 🔧 FIX: Parse rawResponse (includes thinking) instead of content
          const contentToParse = assistantMessage.rawResponse || assistantMessage.content;

          const effectiveToolFormat =
            conversationOverridesRef.current?.toolFormat ?? DEFAULT_TOOL_FORMAT;
          parsed = parseAIResponse(contentToParse, effectiveToolFormat, feature);

          // Attach parsed data to assistantMessage
          assistantMessage.parsed = parsed;

          // 📊 Create parseDebugInfo with detailed action parsing info
          const parseDebugActions = parsed.actions.map((action: any, index: number) => {
            // Check if action has error markers
            const hasError = action.isError || action.errorMessage;
            const status = hasError ? 'error' : 'success';

            // Extract parameter info for debugging
            const extractedParams = Object.entries(action.params).map(([name, value]) => ({
              name,
              found: value !== undefined && value !== null && value !== '',
              length: typeof value === 'string' ? value.length : undefined,
            }));

            return {
              index,
              type: action.type,
              params: action.params,
              status,
              errorMessage: action.errorMessage,
              errorCode: action.errorCode,
              extractedParams,
            };
          });

          const successfulActions = parseDebugActions.filter(
            (a: any) => a.status === 'success',
          ).length;
          const failedActions = parseDebugActions.filter((a: any) => a.status === 'error').length;

          // Count content blocks by type for debugging
          const contentBlockStats = parsed.contentBlocks.reduce((acc: any, block: any) => {
            acc[block.type] = (acc[block.type] || 0) + 1;
            return acc;
          }, {});

          assistantMessage.parseDebugInfo = {
            totalActions: parsed.actions.length,
            successfulActions,
            failedActions,
            actions: parseDebugActions,
            contentBlocks: parsed.contentBlocks.map((block: any, index: number) => ({
              index,
              type: block.type,
              contentLength: block.content?.length || 0,
              language: block.language,
              actionIndex: block.actionIndex,
            })),
            contentBlockStats,
          };

          // Update React state with the parsed data and debug info
          setMessages((prev) =>
            prev.map((m) =>
              m.id === assistantMessageId
                ? {
                    ...m,
                    parsed: assistantMessage.parsed,
                    parseDebugInfo: assistantMessage.parseDebugInfo,
                  }
                : m,
            ),
          );
        } catch (parseError) {
          hasParsingError = true;
          const errorDetails =
            parseError instanceof Error ? parseError.message : 'Unknown parsing error';

          // Create error message with details
          const errorContent = `Error: Failed to parse response\n\nDetails: ${errorDetails}\n\n**Note:** The response was received but could not be displayed due to malformed content. This usually happens when tool calls are missing closing tags.\n\nYou can try:\n- Regenerating the response\n- Asking the assistant to fix the issue`;

          // Update the assistant message to error state
          assistantMessage.content = errorContent;
          assistantMessage.isError = true;
          notifyDesktop('Phantoma', `Failed to parse AI response: ${errorDetails}`);

          // 📊 Create parseDebugInfo for parse errors
          assistantMessage.parseDebugInfo = {
            totalActions: 0,
            successfulActions: 0,
            failedActions: 0,
            actions: [],
            parseError: {
              message: errorDetails,
              rawContent: assistantMessage.content?.substring(0, 500) || '(empty)',
            },
          };

          // Update messages array with error state
          setMessages((prev) =>
            prev.map((m) =>
              m.id === assistantMessageId
                ? {
                    ...m,
                    content: errorContent,
                    isError: true,
                    parseDebugInfo: assistantMessage.parseDebugInfo,
                  }
                : m,
            ),
          );
        }

        saveConversation(
          sessionId,
          folderPath,
          [...updatedMessages, assistantMessage],
          effectiveChatUuid,
          false,
          backendConversationId || backendConversationIdRef.current,
          undefined,
          undefined,
          undefined,
          conversationOverridesRef.current,
        );

        if (
          !hasParsingError &&
          parsed &&
          parsed.actions.length === 0 &&
          !parsed.onlyThinkingDetected &&
          !(assistantMessage.rawResponse || assistantMessage.content || '').trim()
        ) {
          notifyDesktop('Phantoma', 'AI returned empty response.');
        }

        // 🚨 DETECT ONLY-THINKING RESPONSE
        if (!hasParsingError && parsed && parsed.onlyThinkingDetected) {
          console.warn(
            '[Phantoma][sendMessage] ⚠️ Only-thinking response detected - skipping tool execution',
          );
          notifyDesktop('Phantoma', 'AI returned only thinking section, no response content.');
          onTurnCompleteRef.current?.();
          return;
        }

        // ─── NO-TAG FOLLOW-UP ────────────────────────────────────────────────
        // If no tool tags detected: keep the response visible as markdown, but still
        // send a next (follow-up) request with format reminder. The failed response is NOT re-sent.
        if (!hasParsingError && parsed) {
          const { hasRegisteredTag } = await import('../../utils/responseValidation');
          const rawForCheck = assistantMessage.rawResponse || assistantMessage.content;
          const tagMatched = hasRegisteredTag(rawForCheck);
          const dsmlUnconverted = dsmlUnconvertedRef.current;
          dsmlUnconvertedRef.current = false;
          if (tagMatched && !dsmlUnconverted) {
            noTagFollowUpCountRef.current = 0;
          } else if (noTagFollowUpCountRef.current < MAX_NO_TAG_FOLLOWUP) {
            noTagFollowUpCountRef.current += 1;
            console.warn(
              `[DEBUG][NoTagFollowUp] Reason: tagMatched=${tagMatched} dsmlUnconverted=${dsmlUnconverted} → keeping response visible, sending follow-up request ${noTagFollowUpCountRef.current}/${MAX_NO_TAG_FOLLOWUP}`,
            );
            console.warn(
              `[DEBUG][NoTagFollowUp][State] isReq1=${isReq1} skipFirstRequestLogic=${!!skipFirstRequestLogic} uiHidden=${!!uiHidden} filteredMessagesLen=${filteredMessages.length} messagesRefLen=${messagesRef.current.length} userRequestCount=${userRequestCountRef.current} assistantMessageId=${assistantMessageId} parentMessageId=${parentMessageId ?? 'none'} contentLen=${content.length} filesCount=${files?.length ?? 0} followUpWillBeReq1=false (hardcoded skipFirstRequestLogic=true -> isReq1=false)`,
            );
            console.warn(
              `[DEBUG][NoTagFollowUp] Retrying same request (isReq1=${isReq1} skipFirstRequestLogic=${!!skipFirstRequestLogic} isNewSession=${isNewSession}) with original payload, dropping failed response`,
            );
            if (!skipFirstRequestLogic) {
              userRequestCountRef.current = Math.max(0, userRequestCountRef.current - 1);
            }
            messagesRef.current = filteredMessages;
            setMessages(filteredMessages);
            if (isNewSession) {
              currentConversationIdRef.current = '';
              setCurrentConversationId('');
              backendConversationIdRef.current = '';
              qwenParentIdRef.current = undefined;
            }
            return sendMessage(
              content,
              files,
              finalModel,
              finalAccount,
              skipFirstRequestLogic,
              actionIds,
              uiHidden,
              parentMessageId,
              extraOptions,
            );
            // Keep the failed response visible (don't slice it out)
            // messagesRef and setMessages already have updatedMessages with the assistant response
            // Just send the follow-up request without removing the previous response
            return sendMessage(
              content,
              files,
              finalModel,
              finalAccount,
              true, // skipFirstRequestLogic: true to avoid counting as new user request
              actionIds,
              true, // uiHidden: true to hide the follow-up request/response pair
              assistantMessageId, // parentMessageId: link follow-up to the failed response
              extraOptions,
            );
          } else {
            console.warn(
              `[DEBUG][NoTagFollowUp] Follow-up limit reached (${MAX_NO_TAG_FOLLOWUP}) → giving up`,
            );
            noTagFollowUpCountRef.current = 0;
            notifyDesktop(
              'Phantoma',
              'AI failed to use correct tool format after multiple follow-up requests.',
            );
          }
        }
        // ─────────────────────────────────────────────────────────────────────

        if (!hasParsingError && parsed && onMalformedTool) {
          parsed.actions.forEach((action: any, index: number) => {
            if (action.isError) {
              onMalformedTool(
                `${assistantMessageId}-action-${index}`,
                action.type,
                action.errorMessage ?? '',
                action.errorCode ?? '',
              );
            }
          });
        }

        const USER_CONFIRM_TOOLS = ['create_agent'];
        const autoActions =
          !hasParsingError && parsed?.actions
            ? parsed.actions
                .map((a: any, i: number) => ({ ...a, _index: i }))
                .filter((a: any) => !USER_CONFIRM_TOOLS.includes(a.type))
            : [];
        if (
          !hasParsingError &&
          parsed?.actions?.some((a: any) => USER_CONFIRM_TOOLS.includes(a.type))
        ) {
          notifyDesktop('Phantoma', 'Confirmation (Accept) required to continue.');
        }
        if (!hasParsingError && parsed && onToolRequest && autoActions.length > 0) {
          onToolRequest(autoActions, assistantMessage, false, TOOL_ACTION_TYPES.ACCEPT);
        } else {
          // Notify turn complete if no tools were executed or parsing failed
          onTurnCompleteRef.current?.();
        }
      } catch (error) {
        dispatchStreaming({ type: 'RESET_STREAMING' });
        abortControllerRef.current = null;
        noTagFollowUpCountRef.current = 0;

        if (error instanceof Error && error.name === 'AbortError') {
          setIsProcessingSync(false);
          onTurnCompleteRef.current?.();
          return;
        }

        // Fallback: notify turn complete on unexpected errors
        notifyDesktop(
          'Phantoma',
          `Error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        );
        onTurnCompleteRef.current?.();

        console.error('[Zen sendMessage] error:', error);
        const errorMessage: Message = {
          id: `msg-${Date.now()}-error`,
          role: 'assistant',
          content: `Error: ${error instanceof Error ? error.message : JSON.stringify(error)}`,
          timestamp: Date.now(),
          isError: true,
        };

        const messagesWithError = [
          ...messagesRef.current.filter((m) => !m.isCancelled),
          errorMessage,
        ];
        setMessages(messagesWithError);
        messagesRef.current = messagesWithError;

        if (effectiveChatUuid) {
          try {
            saveConversation(
              sessionId,
              folderPath,
              messagesWithError,
              effectiveChatUuid,
              false,
              backendConversationIdRef.current,
              undefined,
              undefined,
              undefined,
              conversationOverridesRef.current,
            );
          } catch (saveErr) {
            console.warn('[useChatLLM] Failed to save conversation:', saveErr);
          }
        }

        setIsProcessingSync(false);
      }
    },
    [
      apiUrl,
      selectedTab,
      aiLanguage,
      treeView,
      workspace,
      uploadFiles,
      setIsProcessingSync,
      setIsContinuingSync,
      dispatchStreaming,
      providerBlockedRanges,
      onTurnCompleteRef,
    ],
  );

  const handleSelectOption = useCallback(
    (messageId: string, option: string) => {
      if (isProcessingRef.current) {
        console.warn(
          `[Zen][handleSelectOption] BLOCKED - already processing, skipping option selection`,
        );
        return;
      }

      setMessages((currentMessages) => {
        let updatedMessages = currentMessages.map((m) =>
          m.id === messageId ? { ...m, selectedOption: option } : m,
        );

        let parsedPayload: {
          allAnswered?: boolean;
          answers?: Record<string, any>;
          questions?: any[];
        } | null = null;

        try {
          const parsed = JSON.parse(option);
          if (parsed.allAnswered === true && parsed.answers) {
            parsedPayload = parsed;
            updatedMessages = currentMessages.map((m) =>
              m.id === messageId ? { ...m, selectedOption: option } : m,
            );
          }
        } catch (e) {
          console.warn('[useChatLLM] Failed to parse option:', e);
        }

        let convId = currentConversationIdRef.current;
        if (!convId) {
          convId = crypto.randomUUID?.() || Date.now().toString();
          currentConversationIdRef.current = convId;
          setCurrentConversationId(convId);
        }

        const sessionId = selectedTab?.sessionId || -1;
        const folderPath = selectedTab?.folderPath || null;

        saveConversation(
          sessionId,
          folderPath,
          updatedMessages,
          convId,
          true,
          backendConversationIdRef.current,
          undefined,
          undefined,
          undefined,
          conversationOverridesRef.current,
        );

        if (parsedPayload && parsedPayload.answers) {
          if (isProcessingRef.current) {
            return updatedMessages;
          }

          setTimeout(() => {
            if (isProcessingRef.current) {
              console.warn(`[Zen][handleSelectOption] Timeout guard: still processing, canceling`);
              return;
            }

            const questions = parsedPayload.questions || [];
            const answers = parsedPayload.answers || {};

            const formattedAnswers = questions
              .map((question: any, index: number) => {
                const qId = question.id;
                const answer = answers[qId];
                const number = index + 1;

                // Check if answer is missing or empty (but allow boolean false)
                if (!answer || (answer.value !== false && !answer.value)) {
                  return `${number}. `;
                }

                // Handle boolean values for confirm type
                if (typeof answer.value === 'boolean') {
                  return `${number}. ${answer.value ? 'Yes' : 'No'}`;
                }

                // Handle array values for multi-choice
                const value = Array.isArray(answer.value)
                  ? answer.value.join(', ')
                  : String(answer.value);
                return `${number}. ${value}`;
              })
              .join('\n');

            const promptText = `<question-answer>\n${formattedAnswers}\n</question-answer>`;
            sendMessage(promptText, undefined, undefined, undefined, true, undefined, true);
          }, 100);
        }

        return updatedMessages;
      });
    },
    [selectedTab, sendMessage],
  );

  const returnValue = useMemo(
    () => ({
      messages,
      setMessages,
      messagesRef,
      isProcessing: streamingState.isProcessing,
      setIsProcessing: setIsProcessingSync,
      isStreaming: streamingState.isStreaming,
      isContinuing: streamingState.isContinuing,
      currentConversationId,
      setCurrentConversationId,
      currentConversationIdRef,
      sendMessage,
      stopGeneration,
      resetSession,
      isProcessingRef,
      setBackendConversationId: (
        id: string,
        meta?: { providerId?: string; modelId?: string; accountId?: string },
      ) => {
        backendConversationIdRef.current = id;
        if (meta) {
          if (meta.providerId && meta.modelId) {
            lastUsedModelRef.current = {
              id: meta.modelId,
              providerId: meta.providerId,
            };
          }
          if (meta.accountId) {
            lastUsedAccountRef.current = { id: meta.accountId };
          }
        }
      },
      conversationToolOverrides,
      setConversationToolOverrides,
      handleSelectOption,
    }),
    [
      messages,
      streamingState,
      currentConversationId,
      sendMessage,
      stopGeneration,
      resetSession,
      setIsProcessingSync,
      conversationToolOverrides,
      handleSelectOption,
    ],
  );

  return returnValue;
};
