/**
 * ------------------------------------------------------------------
 * useDraftManagement
 * ------------------------------------------------------------------
 * Quản lý trạng thái draft message cho chat footer.
 *
 * Main features:
 * - Lưu/khôi phục draft bền vững cho mỗi hội thoại
 * - Ngăn xếp undo/redo cho textarea
 * - Khôi phục input khi revert hội thoại
 * ------------------------------------------------------------------
 */

// ─── Imports ────────────────────────────────────────────────────────────
// ── React ──
import { useState, useRef, useEffect } from 'react';

// ── Utils ──

// ── Services ──
import { extensionService } from '../../../../services/ExtensionService';

// ─── Hook ───────────────────────────────────────────────────────────────
export const useDraftManagement = (
  conversationId: string,
  revertInput: { value: string; nonce: number } | null,
) => {
  const renderCountRef = useRef(0);
  const saveCountRef = useRef(0);
  const restoreCountRef = useRef(0);
  const undoCountRef = useRef(0);
  const redoCountRef = useRef(0);

  renderCountRef.current += 1;

  const [message, setMessage] = useState('');
  const storage = extensionService.getStorage();
  const draftTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isDraftRestoredRef = useRef(false);
  const undoStackRef = useRef<string[]>([]);
  const undoIndexRef = useRef<number>(-1);
  const isUndoingRef = useRef(false);

  // Restore draft on conversation change
  useEffect(() => {
    if (!conversationId) {
      return;
    }

    isDraftRestoredRef.current = false;
    const draftKey = `draft:${conversationId}`;
    storage
      .get(draftKey)
      .then((res: any) => {
        restoreCountRef.current += 1;

        if (res?.value && !isDraftRestoredRef.current && !revertInput?.value) {
          setMessage(res.value);
          undoStackRef.current = [res.value];
          undoIndexRef.current = 0;
        }
        isDraftRestoredRef.current = true;
      })
      .catch((err: unknown) => {
        console.error('[useDraftManagement] ❌ Error restoring draft:', err);
        isDraftRestoredRef.current = true;
      });
  }, [conversationId]);

  // Debounce-save draft on message change
  useEffect(() => {
    if (!conversationId) {
      return;
    }
    if (!isDraftRestoredRef.current) {
      return;
    }

    if (draftTimerRef.current) clearTimeout(draftTimerRef.current);

    draftTimerRef.current = setTimeout(() => {
      saveCountRef.current += 1;

      const draftKey = `draft:${conversationId}`;
      if (message.trim()) {
        storage
          .set(draftKey, message)
          .then(() => {})
          .catch((err: unknown) => {
            console.error('[useDraftManagement] ❌ Error saving draft:', err);
          });
      } else {
        storage
          .delete(draftKey)
          .then(() => {})
          .catch((err: unknown) => {
            console.error('[useDraftManagement] ❌ Error deleting draft:', err);
          });
      }
    }, 500);
    return () => {
      if (draftTimerRef.current) clearTimeout(draftTimerRef.current);
    };
  }, [message, conversationId]);

  // Apply revert input (when user reverts a conversation)
  useEffect(() => {
    if (revertInput?.value !== undefined) {
      setMessage(revertInput.value || '');
      undoStackRef.current = revertInput.value ? [revertInput.value] : [];
      undoIndexRef.current = revertInput.value ? 0 : -1;
    }
  }, [revertInput?.value, revertInput?.nonce]);

  const clearDraft = () => {
    if (conversationId) {
      const draftKey = `draft:${conversationId}`;
      storage
        .delete(draftKey)
        .then(() => {})
        .catch((err: unknown) => {
          console.error('[useDraftManagement] ❌ Error clearing draft:', err);
        });
    }
    undoStackRef.current = [];
    undoIndexRef.current = -1;
  };

  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    if (!isUndoingRef.current) {
      const newStack = undoStackRef.current.slice(0, undoIndexRef.current + 1);
      newStack.push(value);
      undoStackRef.current = newStack;
      undoIndexRef.current = newStack.length - 1;
    }
    setMessage(value);
  };

  const handleKeyDown = (
    e: React.KeyboardEvent<HTMLTextAreaElement>,
    checkMentions: (v: string) => void,
  ) => {
    const isUndo = (e.ctrlKey || e.metaKey) && e.key === 'z' && !e.shiftKey;
    const isRedo =
      ((e.ctrlKey || e.metaKey) && e.key === 'y') ||
      ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'z');

    if (isUndo) {
      e.preventDefault();
      undoCountRef.current += 1;

      if (undoIndexRef.current > 0) {
        isUndoingRef.current = true;
        undoIndexRef.current -= 1;
        const prev = undoStackRef.current[undoIndexRef.current];
        setMessage(prev);
        checkMentions(prev);
        isUndoingRef.current = false;
      } else if (undoIndexRef.current === 0) {
        isUndoingRef.current = true;
        undoIndexRef.current = -1;
        setMessage('');
        checkMentions('');
        isUndoingRef.current = false;
      }
      return;
    }

    if (isRedo) {
      e.preventDefault();
      redoCountRef.current += 1;

      if (undoIndexRef.current < undoStackRef.current.length - 1) {
        isUndoingRef.current = true;
        undoIndexRef.current += 1;
        const next = undoStackRef.current[undoIndexRef.current];
        setMessage(next);
        checkMentions(next);
        isUndoingRef.current = false;
      }
    }
  };

  return {
    message,
    setMessage,
    storage,
    clearDraft,
    handleTextareaChange,
    handleKeyDown,
    undoStackRef,
    undoIndexRef,
  };
};
