import { useState, useEffect, useCallback } from 'react';

import { FlatAccount, Pagination } from '../types';
import { useDbFetch } from '../../../services/useDbFetch';
import { extractAccessToken, isJwtExpired } from '@renderer/utils/jwt';
import { compareAccountsByUsage } from '../../../utils/accountSort';

/** Trạng thái tài khoản dùng cho status badges ở AccountPanel. */
export type AccountStatus = 'active' | 'expired' | 'error' | 'inactive';

/**
 * Suy ra trạng thái của một tài khoản từ dữ liệu hiện có.
 * - active   : is_active_cli === true
 * - expired  : JWT token (accessToken) đã hết hạn
 * - inactive : is_active_cli === false (không phải active/expired)
 * - error    : chưa có nguồn dữ liệu → luôn 0 (chỗ giữ cho tương lai)
 */
export const getAccountStatus = (account: FlatAccount): AccountStatus => {
  if (account.is_active_cli === true) {
    const token = extractAccessToken(account.credential || '');
    if (token && isJwtExpired(token)) return 'expired';
    return 'active';
  }
  const token = extractAccessToken(account.credential || '');
  if (token && isJwtExpired(token)) return 'expired';
  if (account.is_active_cli === false) return 'inactive';
  return 'inactive';
};

const accountEndpoint = (accounts: FlatAccount[], id: string): string =>
  accounts.find((a) => a.id === id)?.is_api_account
    ? `/v1/api-accounts/${id}`
    : `/v1/accounts/${id}`;

const ACCOUNTS_CACHE_KEY = 'zen.accounts.cache.v1';
const PROVIDERS_CACHE_KEY = 'zen.providers.cache.v1';

const readCache = <T>(key: string, fallback: T): T => {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
};

const writeCache = (key: string, value: unknown) => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* quota exceeded — bỏ qua */
  }
};

export const useAccounts = (isOpen: boolean) => {
  const [allAccounts, setAllAccounts] = useState<FlatAccount[]>(() =>
    readCache<FlatAccount[]>(ACCOUNTS_CACHE_KEY, []),
  );
  const [providerConfigs, setProviderConfigs] = useState<any[]>(() =>
    readCache<any[]>(PROVIDERS_CACHE_KEY, []),
  );
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [providerFilter, setProviderFilter] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<AccountStatus | ''>('');
  const [statsPeriod, setStatsPeriod] = useState<'day' | 'week' | 'month' | 'year' | 'all'>('day');
  const [emailFilter, setEmailFilter] = useState<string[]>([]);
  const [pagination, setPagination] = useState<Pagination>({
    total: 0,
    page: 1,
    limit: 10000,
    total_pages: 1,
  });
  const [selectedAccounts, setSelectedAccounts] = useState<Set<string>>(new Set());
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [deleteItem, setDeleteItem] = useState<{
    id: string;
    email?: string;
    provider_name?: string;
    website_url?: string;
  } | null>(null);
  const [deleteLoading, setDeleteLoading] = useState(false);

  // ── Store ──
  const dbFetch = useDbFetch();

  // ── Callbacks ──
  const callBackend = useCallback(
    async (endpoint: string, method: string = 'GET', body?: any) => {
      const options: RequestInit = {
        method,
        cache: 'no-store',
      };
      if (body) options.body = JSON.stringify(body);
      const response = await dbFetch(endpoint, options);
      return response.json();
    },
    [dbFetch],
  );

  const fetchAccounts = useCallback(
    async (page = 1, limit = 20, silent = false, forceProviders = false) => {
      if (!isOpen) return;
      if (!silent) setLoading(true);
      try {
        // Fetch providers nếu chưa có, hoặc bị ép refetch (khi đổi database)
        if (providerConfigs.length === 0 || forceProviders) {
          try {
            const pResult = await callBackend('/v1/providers');
            if (pResult.success && pResult.data) {
              setProviderConfigs(pResult.data);
              writeCache(PROVIDERS_CACHE_KEY, pResult.data);
            }
          } catch (err) {
            console.error('Failed to fetch providers:', err);
          }
        }

        const params = new URLSearchParams({
          page: page.toString(),
          limit: limit.toString(),
          period: statsPeriod,
          offset: '0',
        });
        // searchQuery không gửi lên backend — search đa trường (email + provider_id
        // + provider_name) được thực hiện client-side sau khi fetch.

        if (emailFilter.length === 1) params.append('email', emailFilter[0]);

        const result = await callBackend(`/v1/accounts?${params.toString()}`);
        if (result.success && result.data) {
          const accountsList = result.data.accounts || [];

          // Fetch stats for each account
          const accountsWithStats = await Promise.all(
            accountsList.map(async (acc: any) => {
              try {
                const statsResult = await callBackend(
                  `/v1/stats?period=${statsPeriod}&account_id=${acc.id}`,
                );
                let periodTokens = 0;
                let periodRequests = 0;

                let totalRequests = acc.total_requests || 0;
                let successfulRequests = acc.successful_requests || 0;
                let totalTokens = acc.total_tokens || 0;

                if (statsResult.success && statsResult.data) {
                  // period_requests / period_tokens: tổng từ usage history
                  if (statsResult.data.usage) {
                    periodTokens = statsResult.data.usage.reduce(
                      (sum: number, entry: any) => sum + (entry.tokens || 0),
                      0,
                    );
                    periodRequests = statsResult.data.usage.reduce(
                      (sum: number, entry: any) => sum + (entry.requests || 0),
                      0,
                    );
                  }

                  // total_requests / successful_requests / total_tokens: từ accounts stats
                  if (statsResult.data.accounts?.length) {
                    const accountStat = statsResult.data.accounts.find(
                      (s: any) => s.id === acc.id,
                    );
                    if (accountStat) {
                      totalRequests = accountStat.total_requests ?? totalRequests;
                      successfulRequests = accountStat.successful_requests ?? successfulRequests;
                      totalTokens = accountStat.total_tokens ?? totalTokens;
                    }
                  }
                }

                return {
                  id: acc.id,
                  provider_id: acc.provider_id,
                  email: acc.email,
                  credential: acc.credential,
                  total_requests: totalRequests,
                  successful_requests: successfulRequests,
                  total_tokens: totalTokens,
                  period_requests: periodRequests,
                  period_tokens: periodTokens,
                  user_data_dir: acc.user_data_dir,
                  is_active_cli: acc.is_active_cli,
                  usage: acc.usage ?? null,
                  reset_usage_at: acc.reset_usage_at ?? null,
                  auth_method: acc.auth_method ?? null,
                };
              } catch (err) {
                console.warn(`Failed to fetch stats for account ${acc.id}:`, err);
                return {
                  id: acc.id,
                  provider_id: acc.provider_id,
                  email: acc.email,
                  credential: acc.credential,
                  total_requests: acc.total_requests || 0,
                  successful_requests: acc.successful_requests || 0,
                  total_tokens: acc.total_tokens || 0,
                  period_requests: 0,
                  period_tokens: 0,
                  user_data_dir: acc.user_data_dir,
                  is_active_cli: acc.is_active_cli,
                  usage: acc.usage ?? null,
                  reset_usage_at: acc.reset_usage_at ?? null,
                  auth_method: acc.auth_method ?? null,
                };
              }
            }),
          );

          let apiAccounts: FlatAccount[] = [];
          try {
            const apiResult = await callBackend('/v1/api-accounts?page=1&limit=10000');
            if (apiResult.success && apiResult.data) {
              apiAccounts = (apiResult.data.accounts || []).map((a: any) => ({
                id: a.id,
                provider_id: `api:${a.provider_name}`,
                email: a.label || a.provider_name,
                credential: a.api_key || '',
                usage: a.usage ?? undefined,
                reset_usage_at: a.reset_usage_at ?? undefined,
                is_active_cli: true,
                is_api_account: true,
                auth_method: 'API',
                base_url: a.base_url,
                api_type: a.api_type,
                label: a.label ?? undefined,
                website: a.config?.website,
                config: a.config ?? null,
                expires_at: a.expires_at ?? null,
              }));
            }
          } catch (err) {
            console.error('Failed to fetch API accounts:', err);
          }
          const mergedAccounts = [...accountsWithStats, ...apiAccounts];

          setAllAccounts(mergedAccounts);
          if (emailFilter.length === 0 && statsPeriod === 'day') {
            writeCache(ACCOUNTS_CACHE_KEY, mergedAccounts);
          }
          setPagination({
            total: result.data.pagination?.total || 0,
            page: result.data.pagination?.page || page,
            limit: result.data.pagination?.limit || limit,
            total_pages: result.data.pagination?.total_pages || 1,
          });
        }
      } catch (err) {
        console.error('Failed to fetch accounts:', err);
      } finally {
        if (!silent) setLoading(false);
      }
    },
    [isOpen, emailFilter, providerConfigs.length, callBackend, statsPeriod],
  );

  // ── Effects ──
  useEffect(() => {
    if (isOpen) {
      // Reset về trang 1 + ép refetch providers mỗi khi panel mở HOẶC đổi
      // database (tránh hiện account/provider của database trước đó).
      setPagination((prev) => ({ ...prev, page: 1 }));
      fetchAccounts(1, pagination.limit, allAccounts.length > 0, true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen]);

  // searchQuery được filter client-side → không cần re-fetch khi gõ
  useEffect(() => {
    if (isOpen) {
      fetchAccounts(1, pagination.limit);
    }
  }, [emailFilter, statsPeriod]);

  // ── Handlers ──
  const executeDelete = async () => {
    setDeleteLoading(true);
    try {
      if (deleteItem) {
        await callBackend(accountEndpoint(allAccounts, deleteItem.id), 'DELETE');
      } else if (selectedAccounts.size > 0) {
        await Promise.all(
          Array.from(selectedAccounts).map((id) =>
            callBackend(accountEndpoint(allAccounts, id), 'DELETE'),
          ),
        );
        setSelectedAccounts(new Set());
      }
      setConfirmOpen(false);
      setDeleteItem(null);
      fetchAccounts(pagination.page, pagination.limit, true);
    } catch (err) {
      console.error('Failed to delete accounts:', err);
    } finally {
      setDeleteLoading(false);
    }
  };

  const handleDelete = (
    id: string,
    email?: string,
    provider_name?: string,
    website_url?: string,
  ) => {
    setDeleteItem({ id, email, provider_name, website_url });
    setConfirmOpen(true);
  };

  const handleBulkDelete = () => {
    setDeleteItem(null);
    setConfirmOpen(true);
  };

  const toggleSelection = (id: string) => {
    const newSelected = new Set(selectedAccounts);
    if (newSelected.has(id)) newSelected.delete(id);
    else newSelected.add(id);
    setSelectedAccounts(newSelected);
  };

  const toggleAll = (newSelected: Set<string>) => {
    setSelectedAccounts(newSelected);
  };

  const switchKiroAccount = async (id: string) => {
    try {
      const result = await callBackend(`/v1/accounts/${id}/switch`, 'POST');
      if (result.success) {
        fetchAccounts(pagination.page, pagination.limit, true);
      }
    } catch (err) {
      console.error('Failed to switch account:', err);
    }
  };

  const refreshAccountToken = async (
    id: string,
    providerId: string,
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      const url = `/v1/accounts/${id}/refresh-token`;
      const result = await callBackend(url, 'POST', {
        provider_id: providerId,
      });
      if (result.success) {
        fetchAccounts(pagination.page, pagination.limit, true);
        return { success: true };
      }
      const errMsg = result.message || result.error || 'Refresh failed';
      console.warn(
        '[useAccounts][refreshAccountToken] Failed:',
        errMsg,
        result,
      );
      return { success: false, error: errMsg };
    } catch (err: any) {
      console.error('[useAccounts][refreshAccountToken] Exception:', err);
      return { success: false, error: err?.message || 'Network error' };
    }
  };

  // ── Derived ──
  // Provider name lookup để phục vụ search mở rộng (email | provider_id | provider_name)
  const providerNameById = new Map<string, string>(
    providerConfigs.map((p) => [p.provider_id, p.provider_name || '']),
  );

  // Đếm status trên TOÀN BỘ tài khoản đã fetch (không filter bởi statusFilter)
  const statusCounts: Record<AccountStatus, number> = {
    active: 0,
    expired: 0,
    error: 0,
    inactive: 0,
  };
  for (const acc of allAccounts) {
    statusCounts[getAccountStatus(acc)] += 1;
  }

  // Áp dụng filter client-side: search mở rộng + status.
  const normalizedQuery = searchQuery.trim().toLowerCase();
  const providerScopedAccounts = [...allAccounts].sort(compareAccountsByUsage).filter((acc) => {
    if (statusFilter && getAccountStatus(acc) !== statusFilter) return false;
    if (!normalizedQuery) return true;
    const providerName = providerNameById.get(acc.provider_id) || '';
    return (
      (acc.email || '').toLowerCase().includes(normalizedQuery) ||
      (acc.provider_id || '').toLowerCase().includes(normalizedQuery) ||
      providerName.toLowerCase().includes(normalizedQuery)
    );
  });
  const accounts = providerFilter
    ? providerScopedAccounts.filter((acc) => acc.provider_id === providerFilter)
    : providerScopedAccounts;

  return {
    accounts,
    providerScopedAccounts,
    allAccounts,
    statusCounts,
    statusFilter,
    setStatusFilter,
    loading,
    providerConfigs,
    searchQuery,
    setSearchQuery,
    pagination,
    selectedAccounts,
    confirmOpen,
    setConfirmOpen,
    deleteItem,
    deleteLoading,
    executeDelete,
    fetchAccounts,
    handleDelete,
    handleBulkDelete,
    toggleSelection,
    toggleAll,
    providerFilter,
    setProviderFilter,
    emailFilter,
    setEmailFilter,
    statsPeriod,
    setStatsPeriod,
    switchKiroAccount,
    refreshAccountToken,
  };
};
